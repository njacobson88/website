#' Are the predicted intervals flat?
#' 
#' Is the smooth really flat (meaning that the max and the min values of the smooth are not significantly different?)
#' @param timepred This is the time prediction values from the start to the end of the predictions in intervals dictated by the intervals
#' @param lowerboundvcfx The lower confidence interval of the variable of interest
#' @param upperboundvcfx The upper confidence interval of the variable of interest
#' @param j The index number of the flat function
#' @return The output of this function includes whether flatness is an issue if the output will equal TRUE if it is and FALSE if it isn't.
#' @export

flatfunction=function(timepred=timepred,lowerboundvcfx=lowerboundvcfx,upperboundvcfx=upperboundvcfx,j=j){
  possiblenearpeakupflatmaxupinterval=max(lowerboundvcfx[,j])
  possiblenearpeakupflatminupinterval=min(upperboundvcfx[,j])
  flatissueup=possiblenearpeakupflatmaxupinterval<possiblenearpeakupflatminupinterval
  possiblenearpeakupflatmindowninterval=min(lowerboundvcfx[,j])
  possiblenearpeakupflatmaxdowninterval=max(upperboundvcfx[,j])
  flatissuedown=possiblenearpeakupflatmindowninterval>possiblenearpeakupflatmaxdowninterval
  flaterror=flatissueup==TRUE|flatissuedown==TRUE
  return(flaterror)
}