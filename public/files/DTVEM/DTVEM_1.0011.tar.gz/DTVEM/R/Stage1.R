#' Stage 1 DTVEM
#' 
#' PLEASE USE THE LAG FUNCTION RATHER THAN THIS UNLESS YOU WOULD LIKE TO SPECIFY THIS MANUALLY. This is the function for the stage 1 of DTVEM. Manipulates the data so that it creates a vector that is both in wide and long formats
#' @param ... A list of variable names used in the function e.g. "X","Y" (REQUIRED)
#' @param differentialtimevaryingpredictors The variables that will be a varying-coefficient of differential time (AKA the lags you want to know what times they predict the outcome). This must be specified as a vector using c("variables here"). e.g. c("X","Y") (REQUIRED)
#' @param outcome This is each of the outcome variables. Specified as outcome="outcomevariablename" for a single variable or outcome=c("outcomevariablename1","outcomevariablename2") (REQUIRED)
#' @param numberofknots The number of k selection points used in the model for stage 1 (see ?choose.k in mgcv package for more details) (note that this is for the raw data k2 refers to the k for the re-blocked data), default is 10. The ideal k is the maximum number of data points per person, but this slows down DTVEM and is often not required. (OPTIONAL)
#' @param k3 The number of k selection points used in the model for the time spline (NOTE THAT THIS CONTROLS FOR TIME TRENDS OF THE POPULATION)  (see ?choose.k in mgcv package for more details). Default is 3. (OPTIONAL)
#' @param controlvariables The variables to be controlled for (not lagged). These are traditional covariates in the analysis. These are the variables that will be controlled for in a stationary fashion. To use this use controlvariables = c("list","here") (OPTIONAL)
#' @param predictionstart The differential time value to start with, default is NULL, and the lowest time difference in the time series will be used (use lower value if you're first value if you're interested in a smaller interval prediction) e.g. predictionstart = 1. If this is not specified and using a continuous time model, make sure to set blockdata = TRUE so that it will be automatically chosen. (OPTIONAL)
#' @param predictionsend The differential time value to end with. This means how long you want your largest time difference in the study to be (i.e. if you wanted to predict up to allow time predictions up to 24 hours and your time intervals were specified in hours, you would set predictionsend = 24). If this is not specified and using a continuous time model, make sure to set blockdata = TRUE so that it will be automatically chosen. (OPTIONAL)
#' @param predictionsinterval The intervals to predict between differential time points. If using discrete time do you want the intervals to be specified every discrete interval, if so set this to 1. If this is not specified and using a continuous time model, make sure to set blockdata = TRUE so that it will be automatically chosen. (OPTIONAL)
#' @param namesofnewpredictorvariables This is the name of the predictors. 
#' @param laglongreducedummy This is the long data output from the data manipulation. 
#' @param minimumpracticalsignificance This can be used to set a minimum amount to pass on from DTVEM stage 1 to stage 2, and stage 1.5 to stage 2. This can be useful if too many variables come back as significant, but they would not meet your criteria for practical significance. Set this to a numerical value (e.g. minimumpracticalsignificance=.2). (OPTIONAL, UNCOMMONLY SPECIFIED)
#' @param gamma This can be used to change the wiggliness of the model. This can be useful if the model is too smooth (i.e flat). The lower the number the more wiggly this will be (see ?gam in MGCV for more information). The default is equal to 1. (OPTIONAL, UNCOMMONLY SPECIFIED)
#' @param intermediatestage Should not be changed unless running from DTVEM function. 
#' @param debug This will print more useless information as it goes along. Only useful for troubleshooting problems. (OPTIONAL, UNCOMMONLY SPECIFIED)
#' @param minimumpracticalsignificanceneg minimumpracticalsignificanceneg*-1
#' @param lengthcovariates the number of covariates (+2)
#' @param blockdata IMPORTANT FOR CONTINUOUS-TIME DATA. This re-organizes the raw data into blocks after an exploratory first stage. Default = FALSE. TRUE = Automatic re-organization of data based on the minimum lag number and the time between two lags peaks/valleys. Including a numeric number will automatically re-block the data into chunks at those specific intervals. (REQUIRED FOR CONTINUOUS DATA, OPTIONAL OTHERWISE)
#' @return The output of this function is: The output from the first stage of DTVEM
#' @export
#' 
#' 
stage1=function(differentialtimevaryingpredictors=differentialtimevaryingpredictors,outcome=outcome,predictionstart=predictionstart,predictionsend=predictionsend,predictionsinterval=predictionsinterval,namesofnewpredictorvariables=namesofnewpredictorvariables,laglongreducedummy=laglongreducedummy,gamma=gamma,numberofknots=numberofknots,k3=k3,controlvariables=controlvariables,debug=debug,minimumpracticalsignificance=minimumpracticalsignificance,minimumpracticalsignificanceneg=minimumpracticalsignificanceneg,intermediatestage=FALSE,lengthcovariates=lengthcovariates,blockdata=blockdata){
  #library(mgcv) 
  
  # #TRYING SOMETHING VERY DIFFERENT TO DEAL WITH MISSINGNESS USING RANDOM EFFECTS
  # #MAKE SURE TO COMMENT OUT
  # laglongreducedummy2=laglongreducedummy
  # #MAKE DUMMY INDICATORS OF NA
  # laglongreducedummy2[,c(paste("VAR",1:length(namesofnewpredictorvariables),"isNA",sep=""))]=is.na(laglongreducedummy2[,c(namesofnewpredictorvariables)])
  # #CREATE AN INDEX VARIABLE FOR A RANDOM EFFECT
  # laglongreducedummy2[,c(paste("ID",1:length(namesofnewpredictorvariables),"isNA",sep=""))]=1:nrow(laglongreducedummy2)
  # laglongreducedummy2[,c(paste("ID",1:length(namesofnewpredictorvariables),"isNA",sep=""))][!laglongreducedummy2[,c(paste("VAR",1:length(namesofnewpredictorvariables),"isNA",sep=""))]]=1
  # # laglongreducedummy2[,c(paste("ID",1:length(namesofnewpredictorvariables),"isNA",sep=""))]=lapply(laglongreducedummy2[,c(paste("ID",0:length(namesofnewpredictorvariables),"isNA",sep=""))],factor)
  # 
  # laglongreducedummy2[,c(paste("VAR",1:length(namesofnewpredictorvariables),"isNA",sep=""))]=1*laglongreducedummy2[,c(paste("VAR",1:length(namesofnewpredictorvariables),"isNA",sep=""))]
  # 
  # laglongreducedummy2[,c(namesofnewpredictorvariables)][is.na(laglongreducedummy2[,c(namesofnewpredictorvariables)])]=0
  # mod2 <- gam(outcome ~ s(timediff, by = XlagonX, k = -1) + s(timediff, by = YlagonX, k = -1) + s(timediff, by = XlagonY, k = -1) + s(timediff,by = YlagonY, k = -1) + s(time, k = 3)+s(ID1isNA,by=VAR1isNA,bs="re")+s(ID2isNA,by=VAR2isNA,bs="re")+s(ID3isNA,by=VAR3isNA,bs="re")+s(ID4isNA,by=VAR4isNA,bs="re"), data=laglongreducedummy2,na.action=na.omit,gamma=gamma)
  
  #MODEL SPECIFICATION - MULTIVARIATE OUTCOME  FOR STAGE 1 with SPLINE TERMS
  for(j in 1:(length(namesofnewpredictorvariables))){
    differentialterm=paste("s(timediff, by = ",namesofnewpredictorvariables[j],", k=",numberofknots,")",sep="")
    if(j ==1){
      differentialtermlist=differentialterm
    }else{
      differentialtermlist=paste(differentialtermlist,differentialterm,sep=" + ")
    } 
  }
  
  #WRITE THE MODEL STATEMENTS - NEW MULTIVARIATE OUTCOME
  if (is.null(controlvariables)==TRUE){ #IF CONTROL VARIABLES ARE NOT SPECIFIED
    model<-as.formula(paste("outcome~",differentialtermlist,"+s(time,k=",k3,")"))
  }else{ #IF CONTROL VARIABLES ARE  SPECIFIED
    controlvariablelist=paste(controlvariables,collapse=" + ")
    allpredictorvariables=paste(differentialtermlist,controlvariablelist,sep=" + ")
    model<-as.formula(paste("outcome~",allpredictorvariables,"+s(time,k=",k3,")"))
  }
  
  #print(paste("Varying-coefficient model = ",paste(model)))
  
  #NOW RUN THE USER SPECIFIED MODEL - MULTIVARIATE
  trytest=try(mod <- gam(model, data=laglongreducedummy,na.action=na.omit,gamma=gamma),silent=TRUE)
  if(try(summary(trytest)[2],silent=TRUE)=="try-error"){
    if(intermediatestage==FALSE){
      stop("Error:Stage 1 Failed. Try decreasing k.")
    }else{
      warning("Intermediate stage failed, running without it.")
    }
  }
  
  
  #RANDOM EFFECT DTVEM TO ESTIMATE PERSON-SPECIFIC EFFECTS
  # laglongreducedummy2=laglongreducedummy
  # laglongreducedummy2$ID=factor(as.factor(laglongreducedummy2$ID),ordered =FALSE)
  # 
  # out=gam(outcome~ti(timediff,ID,by=X1lagonX1,k=10,bs="fs"),data=laglongreducedummy2[laglongreducedummy2$ID%in%c(1:20),],gamma=1.2)
  # plot(out,select=1,ylim=c(-.2,.4))
  # plot(out,select=2,ylim=c(-.2,.4))
  # 
  # longpreds=data.frame(matrix(NA,ncol=2,nrow=10*20))
  # for(i in 1:20){
  #   pdat=data.frame(timediff=1:10,ID=1,X1lagonX1=1)
  #   predictions=predict(out,pdat,type="terms",se=TRUE)
  #   longpreds[(((i-1)*10)+1):(i*10),1]=predictions$fit[,"ti(timediff,ID):X1lagonX1"]
  #   longpreds[(((i-1)*10)+1):(i*10),2]=i
  # }


  
  
  #PLOT EACH OF THE VARYING-COEFFICIENT MODELS
  if(intermediatestage==FALSE){
    mainplottitle=paste("DTVEM Stage 1")
  }else{
    mainplottitle=paste("DTVEM Intermediate Stage")
  }
  
  graphnumber=0
  for(i in 1:length(outcome)){
    for(ii in 1:length(differentialtimevaryingpredictors)){
      graphnumber=graphnumber+1
      plot(mod,select=graphnumber,ylab=paste("Beta Coefficient of ",differentialtimevaryingpredictors[ii],"lag on ",outcome[i],sep=""),xlab="Time Differences",main=mainplottitle)
    }
  }
  
  #SET UP PREDICTIONS MATRIX (CALLED pdat)
  #CHANING largestlagdiff to length((predictionstart/predictionsinterval):(predictionsend/predictionsinterval)*predictionsinterval)
  #REVISED PDAT WITH 10x Sampling
  if(is.null(predictionstart)){
    mindiff<-min(laglongreducedummy$timediff,na.rm=TRUE)
    predictionstart<-mindiff
  }
  if(is.null(predictionsend)){
    maxdiff<-max(laglongreducedummy$timediff,na.rm=TRUE)
    predictionsend<-maxdiff
  }
  if(is.null(predictionsinterval)){
    mindiff<-min(laglongreducedummy$timediff,na.rm=TRUE)
    if(isTRUE(blockdata)){ #IF BLOCK DATA IS YES THEN DIVIDE THE MINIMUM DIFFERENCE BY 10 FOR PRECISION
      predictionsinterval<-mindiff/10
    }else{
      predictionsinterval<-mindiff
    }
  }
  
  
  timepred=seq(from=predictionstart,to=predictionsend,by=predictionsinterval)
  #print(paste("long model is =",model))
  pdat=matrix(NA,nrow=length(timepred),ncol=lengthcovariates)
  #print(paste(lengthcovariates,lengthcovariates)
  #print(paste("pdat ncol=",ncol(pdat)))
  
  pdat[,1]=timepred
  pdat[,2]=0
  pdat[,3:(length(differentialtimevaryingpredictors)*length(outcome)+2)]=1
  if(length(controlvariables)>0){ #IF THE COVARIATES ARE INCLUDED, 0 ZERO OUT THE COVARIATES
    pdat[,(lengthcovariates-length(controlvariables)+1):lengthcovariates]=0
  }
  pdat<-data.frame(pdat)
  names(pdat)[1] <- "timediff"
  names(pdat)[2] <- "time"
  
  tempnumbcount=2
  
  #NAME THE VARIABLES IN PDAT
  for (j in 1:length(outcome)){
    for(jj in 1:length(differentialtimevaryingpredictors)){ #NAME THE DIFFERENTIAL TIME VARYING EFFECT VARIABLES
      tempnumbcount=tempnumbcount+1
      names(pdat)[tempnumbcount] <- paste(differentialtimevaryingpredictors[jj],"lagon",outcome[j],sep="")
    }
  }
  tempnumbcount=lengthcovariates-length(controlvariables)*length(outcome)
  if(length(controlvariables)>0){
    for (jjj in 1:length(outcome)){
      for (j in 1:length(controlvariables)){ #NAME THE DIFFERENTIAL TIME VARYING EFFECT VARIABLES
        tempnumbcount=tempnumbcount+1
        jj=j+1+length(differentialtimevaryingpredictors)
        names(pdat)[tempnumbcount] <- paste(controlvariables[j],sep="")
      }
    }
  }
  #/NAMES THE VARIABLES IN PDAT
  
  recordallvaluestriedmat<-matrix(NA,nrow=length(timepred),ncol=(length(differentialtimevaryingpredictors)*length(outcome)))
  
  if(intermediatestage==FALSE){
    cat("Completed stage 1 of DTVEM, now identifying the significant peaks/valleys.\n")
  }
  
  pred <- predict(mod, pdat, type = "terms", se.fit = TRUE)
  valuesfx<-pred$fit
  
  #MULTIvARIATE NAMES
  vectorofnames=NULL
  for(i in 1:length(outcome)){
    for(ii in 1:length(differentialtimevaryingpredictors)){
      vectorofnames=c(vectorofnames,paste(differentialtimevaryingpredictors[ii],"lagon",outcome[i],sep=""))
    }
  }
  #NEXT SECTION TO SORT VARIABLES BY ORIGINAL ORDER
  smoothout=summary(mod)$s.table
  rownames(smoothout)=gsub(".*:","",rownames(smoothout)) #Remove excess from variable names
  smoothout=cbind(smoothout,rownames(smoothout)) #ADD A COLUMN TO INDICATE THE VARIABLE 
  smoothout=smoothout[match(vectorofnames,smoothout[,5]),,drop=FALSE]
  
  predout<-pred$fit
  colnames(predout)=gsub(".*:","",colnames(predout)) #Remove excess from variable names
  predout=data.frame(predout)
  predout<-predout[vectorofnames]
  
  seout<-pred$se
  colnames(seout)=gsub(".*:","",colnames(seout)) #Remove excess from variable names
  seout=data.frame(seout)
  seout<-seout[vectorofnames]
  
  #out <- mydf[matches$Y]
  
  pvaluevcfx<-matrix(NA,nrow=length(vectorofnames),ncol=1)
  valuesvcfx<-matrix(NA,nrow=length(timepred),ncol=length(vectorofnames))
  sevcfx<-matrix(NA,nrow=length(timepred),ncol=length(vectorofnames))
  for (j in 1:length(vectorofnames)){
    pvaluevcfx[j]=as.numeric(smoothout[j,4]) #P-value of smooth terms
    #print(predout)
    #print(predout[,j])
    valuesvcfx[,j]<-predout[,j] #Varying-Coefficients Betas
    sevcfx[,j]<-seout[,j] #Varying-Coefficients SEs
  }
  
  lowerboundvcfx<-valuesvcfx-1.96*sevcfx
  upperboundvcfx<-valuesvcfx+1.96*sevcfx 
  
  #GRAB ALL VALUES THAT ARE NOT SIGNIFICANTLY DIFFERENT FROM THE PEAK
  #THIS IS SET UP FOR THE NEAR PEAK UP LOOP
  feasiblepeaksvalleyssigmat<-matrix(NA,nrow=length(timepred),ncol=length(vectorofnames))
  flaterrormat<-matrix(NA,nrow=length(vectorofnames),ncol=1)
  variablenamesonlysigall<-NULL
  for(j in 1:length(vectorofnames)){
    
    peaks=localMaxima(valuesvcfx[,j])
    if(debug==TRUE){
      print(paste("peaks are",peaks))
    }
    valleys=localMaxima((valuesvcfx[,j])*-1)
    
    #2015.07.02
    sigpeaks=peaks[(abs((valuesvcfx[peaks,j]/sevcfx[peaks,j]))>1.96)&abs(valuesvcfx[peaks,j])>minimumpracticalsignificance]
    sigvalleys=valleys[(abs((valuesvcfx[valleys,j]/sevcfx[valleys,j]))>1.96)&abs(valuesvcfx[valleys,j])>minimumpracticalsignificance]
    #print(sigpeaks)
    #print(sigvalleys)
    peaktimes=timepred[sigpeaks]
    valleytimes=timepred[sigvalleys]
    peakvalleydist <- abs(outer(peaktimes,valleytimes,FUN="-"))
    if(length(peaktimes)>0){
      peakdist=peaktimes[-1]-peaktimes[1:(length(peaktimes)-1)]
    }else{
      peakdist=c()
    }
    if(length(valleytimes)>0){
      valleydist=valleytimes[-1]-valleytimes[1:(length(valleytimes)-1)]
    }else{
      valleydist=c()
    }
    
    peakvalleydist<-c(peakvalleydist,peakdist,valleydist)

    
    if(j==1){
      if(length(peakvalleydist)>0){
        if(peakvalleydist[1]!=""){
          minpeakvalleydist<-min(peakvalleydist,na.rm=TRUE)
        }else{
          minpeakvalleydist=Inf
        }
        #print(paste("minpeakvalleydist = ",minpeakvalleydist))
      }else{
        minpeakvalleydist=Inf
      }
      if(sum(!is.na(c(peaktimes,valleytimes)))>0){
        minpeakvalley<-min(c(peaktimes,valleytimes),na.rm=TRUE)
      }else{
        minpeakvalley=Inf
      }
    }else{
      if(length(peakvalleydist)>0){
        if(peakvalleydist[1]!=""){ #ADDED [1], TO TRY TO STOP WARNING July 7, 2016
          tempminpeakvalleydist=min(peakvalleydist,na.rm=TRUE)
        }else{
          tempminpeakvalleydist=Inf
        }
        #print(paste("tempminpeakvalleydist = ",tempminpeakvalleydist))
      }else{
        tempminpeakvalleydist=Inf
      }
      minpeakvalleydist<-minpeakvalleydist*(minpeakvalleydist<=tempminpeakvalleydist)+tempminpeakvalleydist*(minpeakvalleydist>tempminpeakvalleydist)
      #print(paste("minpeakvalleydist = ",minpeakvalleydist))
      if(sum(!is.na(c(peaktimes,valleytimes)))>0){
        tempminpeakvalley<-min(c(peaktimes,valleytimes),na.rm=TRUE)
      }else{
        tempminpeakvalley=Inf
      }
      minpeakvalley<-minpeakvalley*(minpeakvalley<=tempminpeakvalley)+tempminpeakvalley*(minpeakvalley>tempminpeakvalley)
    }
    
    #APRIL 6, 2016: ADDING MINIMUM PEAK DETECTION
    #RUN THE DIFFERENCES IN PEAKS ALGORITHM RECURSIVELY TO SEE IF THERE ARE ANY DIFFERENCES IN PEAKS
    mintimediff=length(lowerboundvcfx)-round(length(lowerboundvcfx)/5) #LAST 5TH OF THE TIME SERIES DOES NOT COUNT
    for(nnn in 1:round(length(lowerboundvcfx)/5)){
      tempmintimediffvalues=nearbypeakvalleys(values=nnn,lowerCI=lowerboundvcfx,upperCI=upperboundvcfx,timepred=timepred,updown=1,j=j,predictionsend=predictionsend)
      if(length(tempmintimediffvalues)<mintimediff){
        mintimediff=length(tempmintimediffvalues)+1
      }
    }
    mintimenotsig=timepred[mintimediff]
    
    
    #NOW FIND THE NEARBY PEAKS
    nearpeakupsigdiffall=nearbypeakvalleys(values=peaks,lowerCI=lowerboundvcfx,upperCI=upperboundvcfx,timepred=timepred,updown=1,j=j,predictionsend=predictionsend)
    nearpeakdownsigdiffall=nearbypeakvalleys(values=peaks,lowerCI=lowerboundvcfx,upperCI=upperboundvcfx,timepred=timepred,updown=-1,j=j,predictionsend=predictionsend)
    feasiblepeaks=unique(sort(c(peaks,nearpeakupsigdiffall,nearpeakdownsigdiffall))) #COMBINE A LIST OF ALL POTENITAL PEAKS WITH NEARBY PEAKS
    feasiblepeaksig=feasiblepeaks[lowerboundvcfx[feasiblepeaks,j]>minimumpracticalsignificance] #KEEP ONLY THE PEAKS THAT ARE SIGNIFICANTLY GREATER THAN 0
        
    #NOW GRAB THE VALLEYS IN THE SAME WAY
    nearvalleyupsigdiffall=nearbypeakvalleys(values=valleys,lowerCI=lowerboundvcfx,upperCI=upperboundvcfx,timepred=timepred,updown=1,j=j,predictionsend=predictionsend)
    nearvalleydownsigdiffall=nearbypeakvalleys(values=valleys,lowerCI=lowerboundvcfx,upperCI=upperboundvcfx,timepred=timepred,updown=-1,j=j,predictionsend=predictionsend)
    feasiblevalleys=sort(c(valleys,nearvalleyupsigdiffall,nearvalleydownsigdiffall))
    feasiblevalleysig=feasiblevalleys[upperboundvcfx[feasiblevalleys,j]<minimumpracticalsignificanceneg]
    
    #SAVE ALL THE FEASIBLE SIGNIFICANT PEAKS AND VALLEYS INTO ONE VECTOR
    feasiblepeaksvalleyssig=unique(c(feasiblepeaksig,feasiblevalleysig))
    feasiblepeaksvalleyssig=sort(feasiblepeaksvalleyssig[timepred[feasiblepeaksvalleyssig]<predictionsend])
    if(debug==TRUE){
      print(paste("The feasiblepeaksvalleyssig prior to the variable elimination is",paste(feasiblepeaksvalleyssig,collapse=", ")))
    }
    
    #7.16.2015 COMMMENTING OUT
    #ELIMINATE ALL OF THE SIGNIFICANT PEAKS AND VALLEYS THAT ARE NOT ACTUALLY IN THE DATA FRAME
#     removehasnolags<-matrix(NA,length(feasiblepeaksvalleyssig),1)
#     for(jjjjjj in 1:length(feasiblepeaksvalleyssig)){
#       tempdata=laglongreducedummy[which(timepred[feasiblepeaksvalleyssig[jjjjjj]]==laglongreduce$timediff),] #laglongreduce[,differentialtimevaryingpredictors[j]]
#       removehasnolags[jjjjjj]<-abs(is.na(mean(tempdata[,paste(vectorofnames[j],sep="")]+tempdata[,"outcome"],na.rm=TRUE))*1-1)>0 #I ADD THE OUTCOME TO THE PREDICTOR AND MAKE SURE THAT THE COMBINATION IS POSSIBLE
#     }
#     feasiblepeaksvalleyssig=feasiblepeaksvalleyssig[removehasnolags]
#     feasiblepeaksvalleyssig=feasiblepeaksvalleyssig[(timepred[feasiblepeaksvalleyssig] %in% laglongreduce$timediff)]#THIS MAKES SURE THAT THE PEAKS AND VALLEYS THAT ARE GRABBED ARE ACTUALLY PRESENT IN THE DATA SET
#     feasiblepeaksvalleyssig=sort(feasiblepeaksvalleyssig)
    
    if(debug==TRUE){
      print(paste("The feasiblepeaksvalleyssig after to the variable elimination is",paste(feasiblepeaksvalleyssig,collapse=", ")))
    }
    if(length(feasiblepeaksvalleyssig)>0){
      recordallvaluestriedmat[1:length(feasiblepeaksvalleyssig),j]=feasiblepeaksvalleyssig
      feasiblepeaksvalleyssigmat[1:length(feasiblepeaksvalleyssig),j]=feasiblepeaksvalleyssig
    }else{
      if(intermediatestage==FALSE){
        warning(paste("The term '",vectorofnames[j],"lag' has no values that are significantly different from 0.",sep=""))
      }
      next
    }
    
    
    feasiblepeaksvalleyssigmatBACKUP=feasiblepeaksvalleyssigmat
    #THROW AN WARNING IF THE TERMS ARE NOT SIGNIFICNATLY DIFFERENT FROM 0 AND IF THE P_VALUE IS NOT SIGNIFICANT
    if(sum(!is.na(feasiblepeaksvalleyssigmat[,j]))==0){
      if(intermediatestage==FALSE){
        warning(paste("The term '",vectorofnames[j],"lag' has no values that are significantly different from 0.",sep=""))
      }else{
        next
      }
    }
    if(pvaluevcfx[j]>.05){
      if(intermediatestage==FALSE){
        warning(paste("The term '",vectorofnames[j],"lag' varing-coefficient term is not significantly different from 0.",sep=""))
      }else{
        next
      }
    }
    
    flaterror=flatfunction(timepred=timepred,lowerboundvcfx=lowerboundvcfx,upperboundvcfx=upperboundvcfx,j=j)
    if(is.na(flaterror)){
      if(intermediatestage==FALSE){
        warning(paste("It looks like all peaks might be very flat, such that the highest peak is not significantly different fromt the smallest valley for variable '",vectorofnames[j],"lag'.",sep=""))
      }
      next
    } else if(flaterror==TRUE){
      if(intermediatestage==FALSE){
        warning(paste("It looks like all peaks might be very flat, such that the highest peak is not significantly different fromt the smallest valley for variable '",vectorofnames[j],"lag'.",sep=""))
      }
      next
    }
    
    #THIS STEP IS TO GRAB THE VARIABLE NAMES THAT ARE SIGNIFICANT IN EACH VARIABLE AND PUT THEM INTO A SINGLE MATRIX (VARIABLENAMESONLYSIGALL)
    #THESE ARE THE VARIABLE NAMES THAT WILL BE USED FOR THE WIDE MODEL
    variablename2=as.name(vectorofnames[j])
    
    variablenamesvector=paste(variablename2,"lag",timepred,sep="")#TRYING THIS
    if(debug==TRUE){
      print(paste("The variablenamesvector is ",paste(variablenamesvector,collapse=", "),"the feasiblepeaksvalleyssig is",paste(feasiblepeaksvalleyssig,collapse=", ")))
    }
    variablenamesonlysig=variablenamesvector[(feasiblepeaksvalleyssig)] #GRAB THE SIGNIFICANT VARIABLES, +1 is used to the peak vallues identified because the variablenamesvector begins with lag0
    

    if(j==1){
      variablenamesonlysigall<-variablenamesonlysig
      if(debug==TRUE){
        print(paste("The variablenamesonlysigall is equal to ",paste(variablenamesonlysigall,collapse=", ")))
      }
    }else{
      variablenamesonlysigall<-c(variablenamesonlysigall,variablenamesonlysig)
      
      if(debug==TRUE){
        print(paste("The variablenamesonlysigall is equal to ",paste(variablenamesonlysigall,collapse=", ")))
      }
    }
  }
  
  if(!exists("variablenamesvector")){
    variablenamesvector=NULL
  }
  returnlist=list("mod"=mod,"model"=model,"variablenamesonlysigall"=variablenamesonlysigall,"variablenamesvector"=variablenamesvector,"minpeakvalleydist"=minpeakvalleydist,"minpeakvalley"=minpeakvalley,"mintimenotsig"=mintimenotsig,"predictionstart"=predictionstart,"predictionsend"=predictionsend,"predictionsinterval"=predictionsinterval,"valuesvcfx"=valuesvcfx,"sevcfx"=sevcfx,"pdat"=pdat,"vectorofnames"=vectorofnames)
  return(returnlist)
}