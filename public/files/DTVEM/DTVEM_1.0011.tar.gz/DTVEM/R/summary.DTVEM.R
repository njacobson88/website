#' Summary of DTVEM Object
#' 
#' @param object The DTVEM object saved from the LAG function e.g. (out<-LAG(); summary(out))
#' @param ... other arguments
#' @export
summary.DTVEM<-function(object, ...){
  #STAGE1 PLOT
  mainplottitle=paste("DTVEM Stage 1")
  graphnumber=0
  for(i in 1:length(object$predictorsoutcomelist$outcome)){
    for(ii in 1:length(object$predictorsoutcomelist$differentialtimevaryingpredictors)){
      graphnumber=graphnumber+1
      plot(object$stage1out$mod,select=graphnumber,ylab=paste("Beta Coefficient of ",object$predictorsoutcomelist$differentialtimevaryingpredictors[ii],"lag on ",object$predictorsoutcomelist$outcome[i],sep=""),xlab="Time Differences",main=mainplottitle)
    }
  }
  
  #SUMMARIZE MISSINGNESS IN REBLOCKED DATA
  if(!is.null(object$reblocklist$missingmat)){
    for(i in 1:nrow(object$reblocklist$missingmat)){
      cat(paste("\t",object$reblocklist$missingmat[i,1],"% of the data between predictor ",object$reblocklist$missingmat[i,2]," and ",object$reblocklist$missingmat[i,3],sep="")," is missing\n")
    }
  }
  
  #SUMMARIZE FINAL STAGE 2
  if(!is.null(object$gamstage2out)){
    print(summary(object$gamstage2out$widemodelout$gam))
  }
  
  #SUMMARIZE FINAL STAGE 2
  if(!is.null(object$OpenMxstage2out)){
    print(summary(object$OpenMxstage2out$multisubjectRun))
    print(object$OpenMxstage2out$OpenMxout)
  }
  
  #REMINDER OF REBLOCK DATA INTERVAL
  if(object$reblocklist$blockdata!=FALSE){
    cat(paste("Note that each lag represents an increase in",object$reblocklist$blockdata,"time units"),"\n")
  }
  
}