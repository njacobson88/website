#CATCH UNEQUAL SPACING AND REPLACE WITH EQUALLY SPACED DATA-FRAME
unequaltoequal=function(input_list=input_list,data=data,ID=ID,Time=Time,stage1out=stage1out,rounddecimals=rounddecimals,numberofvars=numberofvars){
  
  data<-data[with(data, order(ID, Time)), ]
  
  nrowold=nrow(data)
  
  #AVERAGE DATA THAT CONTAINS THE SAME ID AT THE SAME TIME
  data=suppressWarnings(aggregate(data,by=list(data[,ID],data[,Time]),FUN=mean, na.rm=TRUE))
  data=data[with(data, order(ID, Time)), ]
  
  nrownew=nrow(data)
  
  if(nrowold!=nrownew){
    warning("The supplied date set contains multiple entries at the same time, using the same ID. These values were automatically averaged. You should only be concerned if you would not like them to be averaged.")
  }
  
  
  newdata<-matrix(NA,nrow=nrow(data),ncol=(numberofvars+2)) #CREATING THIS FOR THE STANDARDIZED data
  
  #CREATE THE ID & TIME COLUMN IN A NEW DATASET
  newdata[,1]<-data[,ID] #ID Column 
  newdata[,2]<-data[,Time] #Time Column 
  
  #NAME ID & TIME COLUMNS
  names(newdata)[1] <- "ID" 
  names(newdata)[2] <- "Time"
  
  #CREATE A data FRAME FOR NEWDATA
  newdata2<-data.frame(newdata) #NEWDATA AND NEWDATA ARE BASICALLY TEMPORARY MATRICES THAT JUST STORE ID AND TIME FOR THE Timelags data Frame to FOllow
  #CREATE TIME VARIABLE TIME LAGS
  
  
  #CREATE TIME LAGS BY ID
  Timelags <- ddply(.data = newdata2, .variables = .(newdata[,1]), function(x){
    data.frame(lag(zoo(x[,2]), k = 0:-1))})
  
  #FIND SMALLEST ADJACENT LAGS
  adjacenttimediffs=Timelags$lag0-Timelags$lag.1 
  
  minlag=min(adjacenttimediffs,na.rm=TRUE)
  avlag=mean(adjacenttimediffs,na.rm=TRUE)
  medlag=median(adjacenttimediffs,na.rm=TRUE)
  maxlag=max(adjacenttimediffs,na.rm=TRUE)
  lowerquartile=quantile(adjacenttimediffs,.25,na.rm=TRUE)
  tenthquantile=quantile(adjacenttimediffs,.1,na.rm=TRUE)
  
  
  unequalintervals=minlag!=maxlag
  
  if(unequalintervals){
    cat(paste("The supplied dataset is not equally spaced. The current version of DTVEM requires data to be equally spaced for the confirmatory step. The current version of DTVEM will automatically set the smallest time block to the lower quartile of two adjacent time values collected, across all subjects, rounded to the decimal place in the time variable provided in the dataset. \n", sep=""))
    cat(paste("However, these values can be manually set using blockdata = X, and rounddecimals = X. See ?LAG for more details.\n", sep=""))
    cat(paste("The following information can help you to make this decision.\n Here is the information based on the adjacent lag times:\n", sep=""))
    cat(paste("The median time between adjacent data points is: ",medlag,"\n", sep=""))
    cat(paste("The average time between adjacent data points is: ",avlag,"\n", sep=""))
    cat(paste("The minimum time between adjacent data points is: ",minlag,"\n", sep=""))
    cat(paste("The maximum time between adjacent data points is: ",maxlag,"\n", sep=""))
    cat(paste("The lower quartile (i.e. 25th quantile) of the time between adjacent data points is: ",lowerquartile,"\n", sep=""))
    cat(paste("The 10th quantile of the time between adjacent data points is: ",tenthquantile,"\n", sep=""))
    
    
    cat("The following information can be used to pick which time blocks you would like based on the first stage of DTVEM:\n\t(1) the smallest lag time\n\t(2) the smallest time difference between lags\n\t(3) the amount of missing data at different lag times\n")
    cat(paste("The first significant peak or valley is",round(stage1out$minpeakvalley,rounddecimals),"\n"))
    if(!is.na(stage1out$minpeakvalleydist)){
      if(stage1out$minpeakvalleydist<Inf){
        cat(paste("The smallest distance between significant peaks or valleys is",round(stage1out$minpeakvalleydist,rounddecimals),"\n"))
      }else{
        cat("There was not more than 1 lag that was significant\n")
      }
    }else{
      cat("There was not more than 1 lag that was significant\n")
    }
    if(!is.na(stage1out$mintimenotsig)){
      cat(paste("The smallest time difference that is not significantly different is",round(stage1out$mintimenotsig,rounddecimals),"\n"))
    }
  }
  
  
  
  return(list("unequalintervals"=unequalintervals,"lowerquartile"=lowerquartile))
}