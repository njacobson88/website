#' Determine the number of decimal places
#' 
#' Determines the max number of decimal places based on the last non-zero digit.
#' @param x A vector of numbers to examine for the last number of decimal places
#' @return The number of decimal places used in a round command
#' @export
decimalplaces <- function(x) {
  decvalues=rapply(strsplit(sub('0+$', '', as.character(x)), ".", fixed=TRUE), function(x) x[2])
  intvalues=rapply(strsplit(as.character(x), ".", fixed=TRUE), function(x) x[1])
  decvalues=decvalues[!is.na(decvalues)]
  intvalues=intvalues[!is.na(intvalues)]
  intvalues=intvalues[intvalues!=0]
  decpl=nchar(decvalues)
  intpl=-1*(nchar(intvalues)-nchar(sub('0+$','',intvalues)))
  pl=c(decpl,intpl)
  max(pl)
}