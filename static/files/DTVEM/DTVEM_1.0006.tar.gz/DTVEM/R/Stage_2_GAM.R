#' Stage 2 DTVEM: Multilevel model with a non-linear spline term for time
#' 
#' PLEASE USE THE LAG FUNCTION RATHER THAN THIS UNLESS YOU WOULD LIKE TO SPECIFY THIS MANUALLY. This runs the confirmatory stage of DTVEM using multilevel models and the spline effect of time.
#' @param Timelagsdummy The data frame with lags from data manipulation
#' @param variablenamesonlysigall The variables to be included in the confirmatory model
#' @param independentpredictors This is whether or not the wide model comparisons should be run independently and combined via stepwise regression with backward selection. This can be useful to reduce the amount of lags included in the confirmatory model. 
#' @param k3 The number of k selection points used in the model for the time spline (NOTE THAT THIS CONTROLS FOR TIME TRENDS OF THE POPULATION)  (see ?choose.k in mgcv package for more details). Default is 3. (OPTIONAL)
#' @return The output of this function is: The output from the second stage of DTVEM in mgcv's gam
#' @export
#' 

#NEXT MAJOR STEP WIDE MODEL RUN
gamstage2=function(Timelagsdummy=Timelagsdummy,variablenamesonlysigall=variablenamesonlysigall,independentpredictors=independentpredictors,k3=k3){
  if(independentpredictors==TRUE){
    independentpredictortvalue=matrix(NA,nrow=length(variablenamesonlysigall),ncol=1) 
    independentpredictorsig=matrix(NA,nrow=length(variablenamesonlysigall),ncol=1) 
    #I TAKE THE NORMAL GAM CODE AND RUN MULTIPLE PRELIMINARY INVESTIGATIONS TO SEE IF EACH VARIABLE IS SIGNIFICANT INDEPENDENTLY BEFORE COMBINING THEM
    for(jjj in 1:length(variablenamesonlysigall)){
      widemodel<-as.formula(paste("outcome ~",paste(variablenamesonlysigall[jjj],collapse = " + "),"+ s(time,k=",k3,")",sep=""))
      modelransuccessfully=1 #FOR ERROR DETECTION
      modelransuccessfully=try(widemodelout<-gamm(widemodel,list(ID=~1),data=Timelagsdummy),silent=TRUE)
      if(try(summary(modelransuccessfully)[2],silent=TRUE)=="try-error"){ #IF MODEL DID NOT RUN SUCCESSFULLY RUN IN GAMM
        warning("In the wide format (stage 2), the model with the random person-specific intercept did not converge. As such, the model estimates that are entirely fixed effects model.")
        modelransuccessfully=1#FOR ERROR DETECTION
        
        modelransuccessfully=try(widemodelout<-gam(widemodel,data=Timelagsdummy),silent=TRUE)
        if(try(summary(modelransuccessfully)[2],silent=TRUE)=="try-error"){#IF MODEL DID NOT RUN SUCCESSFULLY RUN IN GAM with time varying coefficient
          widemodel<-as.formula(paste("outcome ~",paste(variablenamesonlysigall[jjj],collapse = " + "),sep=""))
          widemodelout<-gam(widemodel,data=Timelagsdummy)
        }
        widemodelout$gam<-widemodelout
      }
      #print(summary(widemodelout$gam))
      rawwidecoefficients=summary(widemodelout$gam)$p.coeff
      rawwideSE=summary(widemodelout$gam)$se  
      rawwidesig=summary(widemodelout$gam)$p.pv
      rawwidetvalue=summary(widemodelout$gam)$p.t
      numberofcoefficientsinmodel=length(rawwidesig)-1
      widecoefficients<-rawwidecoefficients[2:(numberofcoefficientsinmodel+1)]+rawwidecoefficients[1]
      widese<-rawwideSE[2:(numberofcoefficientsinmodel+1)]
      widesig<-rawwidesig[2:(numberofcoefficientsinmodel+1)]
      rawwidetvalue=rawwidetvalue[2:(numberofcoefficientsinmodel+1)]
      
      if(widesig<.05&!is.na(widesig)){ #THIS STEP RE-COMPILES THE VARIABLENAMESONLYSIGALL TO ONLY INCLUDE VARIABLES THAT ARE SIGNIFICANT
        independentpredictorsig[jjj]=variablenamesonlysigall[(jjj)]
        independentpredictortvalue[jjj]=rawwidetvalue
      }
    }
    variablenamesonlysigall<-c(independentpredictorsig[!is.na(independentpredictorsig)]) #REMOVE NA
    independentpredictortvalue=c(independentpredictortvalue[!is.na(independentpredictorsig)]) #REMOVE NA
    variablenamesonlysigall<-variablenamesonlysigall[rev(order(abs(independentpredictortvalue)))] #Sort by Tvalue
    independentpredictortvalue=independentpredictortvalue[rev(order(abs(independentpredictortvalue)))] #Sort by Tvalue
    primarysig=variablenamesonlysigall[1]
    #print(paste("The value of primarysig is",primarysig))
    for(jjj in 2:length(variablenamesonlysigall)){
      #print(paste("The value of jjj is",jjj))
      independentpredictorsig=matrix(NA,nrow=length(variablenamesonlysigall),ncol=1)
      for(jjjj in 1:length(variablenamesonlysigall[])){
        #print(paste("The value of jjjj is",jjjj))
        widemodel<-as.formula(paste("outcome ~",paste(unique(c(primarysig,variablenamesonlysigall[jjjj])),collapse = " + "),"+ s(time,k=",k3,")",sep=""))
        modelransuccessfully=1 #FOR ERROR DETECTION
        modelransuccessfully=try(widemodelout<-gamm(widemodel,list(ID=~1),data=Timelagsdummy),silent=TRUE)
        if(try(summary(modelransuccessfully)[2],silent=TRUE)=="try-error"){ #IF MODEL DID NOT RUN SUCCESSFULLY RUN IN GAMM
          warning("In the wide format (stage 2), the model with the random person-specific intercept did not converge. As such, the model estimates that are entirely fixed effects model.")
          modelransuccessfully=1#FOR ERROR DETECTION
          
          modelransuccessfully=try(widemodelout<-gam(widemodel,data=Timelagsdummy),silent=TRUE)
          if(try(summary(modelransuccessfully)[2],silent=TRUE)=="try-error"){#IF MODEL DID NOT RUN SUCCESSFULLY RUN IN GAM with time varying coefficient
            widemodel<-as.formula(paste("outcome ~",paste(unique(c(primarysig,variablenamesonlysigall[jjjj])),collapse = " + "),sep=""))
            widemodelout<-gam(widemodel,data=Timelagsdummy)
          }
          widemodelout$gam<-widemodelout
        }
        #print(summary(widemodelout$gam))
        #print(paste("The value of widemodel is",paste(widemodel,collapse="")))
        rawwidecoefficients=summary(widemodelout$gam)$p.coeff
        rawwideSE=summary(widemodelout$gam)$se  
        rawwidesig=summary(widemodelout$gam)$p.pv
        rawwidetvalue=summary(widemodelout$gam)$p.t
        numberofcoefficientsinmodel=length(rawwidesig)-1
        widecoefficients<-rawwidecoefficients[2:(numberofcoefficientsinmodel+1)]+rawwidecoefficients[1]
        widese<-rawwideSE[2:(numberofcoefficientsinmodel+1)]
        widesig<-rawwidesig[2:(numberofcoefficientsinmodel+1)]
        #print(paste("The value of widesig is",widesig))
        rawwidetvalue=rawwidetvalue[2:(numberofcoefficientsinmodel+1)]
        #print(paste("The value of widesig[jjj] is",widesig[jjj]))
        #print(paste("The value of rawwidetvalue[jjj] is",rawwidetvalue[jjj]))
        if(widesig[jjj]<.05&!is.na(widesig[jjj])){ #THIS STEP RE-COMPILES THE VARIABLENAMESONLYSIGALL TO ONLY INCLUDE VARIABLES THAT ARE SIGNIFICANT
          independentpredictorsig[jjjj]=variablenamesonlysigall[(jjjj)]
          independentpredictortvalue[jjjj]=rawwidetvalue[jjj]
        }
      }
      
      variablenamesonlysigall<-c(independentpredictorsig[!is.na(independentpredictorsig)]) #REMOVE NA
      independentpredictortvalue=c(independentpredictortvalue[!is.na(independentpredictorsig)]) #REMOVE NA
      #print(paste("The value of variablenamesonlysigall is",variablenamesonlysigall))
      #print(paste("The value of independentpredictortvalue is",independentpredictortvalue))
      variablenamesonlysigall<-variablenamesonlysigall[rev(order(abs(independentpredictortvalue)))] #Sort by Tvalue
      independentpredictortvalue=independentpredictortvalue[rev(order(abs(independentpredictortvalue)))] #Sort by Tvalue
      #print(paste("The value of variablenamesonlysigall is",variablenamesonlysigall))
      #print(paste("The value of independentpredictortvalue is",independentpredictortvalue))
      if(length(variablenamesonlysigall)>0){
        primarysig=unique(c(primarysig,variablenamesonlysigall[1]))
        #print(paste("The value of primarysig is",primarysig))
      }else{
        break
      }
    }
    variablenamesonlysigall<-primarysig
  }
  widemodel<-as.formula(paste("outcome ~",paste(variablenamesonlysigall,collapse = " + "),"+ s(time,k=",k3,")",sep=""))
  modelransuccessfully=1 #FOR ERROR DETECTION
  modelransuccessfully=try(widemodelout<-gamm(widemodel,list(ID=~1),data=Timelagsdummy),silent=TRUE)
  if(try(summary(modelransuccessfully)[2],silent=TRUE)=="try-error"){ #IF MODEL DID NOT RUN SUCCESSFULLY RUN IN GAM
    warning("In the wide format (stage 2), the model with the random person-specific intercept did not converge. As such, the model estimates that are entirely fixed effects model.")
    modelransuccessfully=1#FOR ERROR DETECTION
    
    modelransuccessfully=try(widemodelout<-gam(widemodel,data=Timelagsdummy),silent=TRUE)
    if(try(summary(modelransuccessfully)[2],silent=TRUE)=="try-error"){#IF MODEL DID NOT RUN SUCCESSFULLY RUN IN GAM with time varying coefficient
      warning("In the wide format (stage 2), the model with the time spline effect did not converge, removing spline and trying again.")
      widemodel<-as.formula(paste("outcome ~",paste(variablenamesonlysigall,collapse = " + "),sep=""))
      widemodelout<-gam(widemodel,data=Timelagsdummy)
    }
    widemodelout$gam=widemodelout
  }
  
  print(summary(widemodelout$gam))
  
  
  rawwidecoefficients=summary(widemodelout$gam)$p.coeff
  rawwideSE=summary(widemodelout$gam)$se  
  rawwidesig=summary(widemodelout$gam)$p.pv
  numberofcoefficientsinmodel=nrow(as.matrix(variablenamesonlysigall))
  widecoefficients<-rawwidecoefficients[2:(numberofcoefficientsinmodel+1)]+rawwidecoefficients[1]
  widese<-rawwideSE[2:(numberofcoefficientsinmodel+1)]
  widesig<-rawwidesig[2:(numberofcoefficientsinmodel+1)]
  controlswidelong=variablenamesonlysigall[widesig<.05] #THESE ARE THE COEFFICIENTS THAT ARE SIGNIFICANT.
  
  gam2returnlist=list("widemodel"=widemodel,"widemodelout"=widemodelout,"rawwidecoefficients"=rawwidecoefficients,"rawwideSE"=rawwideSE,"rawwidesig"=rawwidesig,"numberofcoefficientsinmodel"=numberofcoefficientsinmodel,"widese"=widese,"widesig"=widesig,"controlswidelong"=controlswidelong)
  return(gam2returnlist)
}