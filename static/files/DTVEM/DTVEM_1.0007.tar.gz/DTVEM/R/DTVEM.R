#' Differential Time-Varying Effect model (DTVEM)
#' 
#' This is the PRIMARY DTVEM function. It combines (1) exploratory lag identication, followed by confirmatory lag identifcation. This function will work with discrete or continuous time data (note that the underlying model is assumes to be discrete even when randomly measured). This function can handle multivariate predictors and multivariate outcomes (or univariate for both). The function will also automatically apply data manipulation required to run the models specified in Jacobson, Chow, and Newman (2019).
#' @param ... A list of variable names used in the function e.g. "X","Y" (REQUIRED)
#' @param differntialtimevaryingpredictors The variables that will be a varying-coefficient of differential time (AKA the lags you want to know what times they predict the outcome). This must be specified as a vector using c("variables here"). e.g. c("X","Y") (REQUIRED)
#' @param outcome This is each of the outcome variables. Specified as outcome="outcomevariablename" for a single variable or outcome=c("outcomevariablename1","outcomevariablename2") (REQUIRED)
#' @param data Specify the data frame that contains the data e.g. data=dataframename (REQUIRED)
#' @param ID The name of the ID variable. E.G. ID = "ID" (must be specified). (REQUIRED)
#' @param Time The name of the Time variable. E.G. Time = "Time" (must be specified). (REQUIRED)
#' @param k The number of k selection points used in the model for stage 1 (see ?choose.k in mgcv package for more details) (note that this is for the raw data k2 refers to the k for the re-blocked data), default is 10. The ideal k is the maximum number of data points per person, but this slows down DTVEM and is often not required. (OPTIONAL, BUT RECOMMENDED)
#' @param k2 The number of k selection points used in the model for stage 1 of the blocked data (see ?choose.k in mgcv package for more details). Default is 10. The ideal k is the maximum number of data points per person, but this slows down DTVEM and is often not required. (OPTIONAL)
#' @param k3 The number of k selection points used in the model for the time spline (NOTE THAT THIS CONTROLS FOR TIME TRENDS OF THE POPULATION)  (see ?choose.k in mgcv package for more details). Default is 3. (OPTIONAL)
#' @param k4 The number of k selection points used in the model for the varying coefficient in the intermediate stage (see ?choose.k in mgcv package for more details). Default is 3. (OPTIONAL, BUT RECOMMENDED)
#' @param controlvariables The variables to be controlled for (not lagged). These are traditional covariates in the analysis. These are the variables that will be controlled for in a stationary fashion. To use this use controlvariables = c("list","here") (OPTIONAL)
#' @param controllag The time of the lag which coviarates should be controlled for (NOT CURRENTLY FUNCTIONAL)
#' @param predictionstart The differential time value to start with, default is NULL, and the lowest time difference in the time series will be used (use lower value if you're first value if you're interested in a smaller interval prediction) e.g. predictionstart = 1. If this is not specified and using a continuous time model, make sure to set blockdata = TRUE so that it will be automatically chosen. (OPTIONAL)
#' @param predictionsend The differential time value to end with. This means how long you want your largest time difference in the study to be (i.e. if you wanted to predict up to allow time predictions up to 24 hours and your time intervals were specified in hours, you would set predictionsend = 24). If this is not specified and using a continuous time model, make sure to set blockdata = TRUE so that it will be automatically chosen. (OPTIONAL)
#' @param predictionsinterval The intervals to predict between differential time points. If using discrete time do you want the intervals to be specified every discrete interval, if so set this to 1. If this is not specified and using a continuous time model, make sure to set blockdata = TRUE so that it will be automatically chosen. (OPTIONAL)
#' @param standardized This specifies whether all of the variables (aside from Time) should be standardized. Options are TRUE, FALSE, and "center". TRUE means within-person standardize each variable (aka get the person-centered z-scores), FALSE means use the raw data, "center" means to only within-person mean-center the variables. Default = TRUE. FALSE is not recommended unless you have done these transformations yourself (OPTIONAL)
#' @param software This is the software used to run the secondary analysis. State-space models are implemented by the argument "OpenMx". The option "gam" can be used to run a traditional multilevel model with a spline that controls for non-linear time trends at the population level. The option "hybrid" first runs a multilevel model then runs an state-space model. Model. Note that the state-space approach can be very slow with large amounts of lags, and consequently "gam" should be used with large amounts of lags are included. However, state-space model estimation is generally marginally superior to the multilevel modeling approach, and if using small amounts of lags or time is not an issue the state-space option is recommended. The default is "OpenMx" which implements multilevel models. (OPTIONAL)
#' @param minimumpracticalsignificance This can be used to set a minimum amount to pass on from DTVEM stage 1 to stage 2, and stage 1.5 to stage 2. This can be useful if too many variables come back as significant, but they would not meet your criteria for practical significance. Set this to a numerical value (e.g. minimumpracticalsignificance=.2). (OPTIONAL, UNCOMMONLY SPECIFIED)
#' @param gamma This can be used to change the wiggliness of the model. This can be useful if the model is too smooth (i.e flat). The lower the number the more wiggly this will be (see ?gam in MGCV for more information). The default is equal to 1. (OPTIONAL, UNCOMMONLY SPECIFIED)
#' @param independentpredictors This is whether or not the wide model comparisons should be run independently and combined via stepwise regression with backward selection. This can be useful to reduce the amount of lags included in the confirmatory model. Default is FALSE. (OPTIONAL) 
#' @param minN The smallest N that will be considered in the stage 2 model (i.e. this can be important in case you don't have observations at certain differential times, such as overnight observations). Default = 30. (OPTIONAL)
#' @param ResidualAnalysis Only applies when software = "OpenMx". Analyze the residuals of the time series with OpenMx after factoring out the non-linear effect of time (takes time trends into account). Can be run only at the group level (faster), or it can also be run with a random effect splines of time (slower) by setting ResidualAnalysis = "Individual". Default = "Group" (OPTIONAL)
#' @param blockdata This re-organizes the raw data into blocks after an exploratory first stage. Default = FALSE. TRUE = Automatic re-organization of data based on the minimum lag number and the time between two lags peaks/valleys. Including a numeric number will automatically re-block the data into chunks at those specific intervals. (OPTIONAL, UNCOMMONLY SPECIFIED)
#' @param rounddecimals The default option is TRUE which to automatically rounds the decimals to the smallest non-zero decimal place in the data. Can also specify a number to round to a specific decimal place (e.g. 1 = the tenths digit, 2 = the hundredths digit, 0 = the nearest whole number, -1 = the nearest 10th number) (OPTIONAL, UNCOMMONLY SPECIFIED)
#' @param OpenMxStartingValues Only applies when software = "OpenMx". Specify the starting values for OpenMx. Since OpenMx will 10 different runs before giving up on convergence this does not usually need to be specified. It should mostly only be specified if there is a convergence issue with OpenMx. Default is 0.3.  (OPTIONAL, UNCOMMONLY SPECIFIED)
#' @param maxintermediaterounds The maximum number of intermediate stages to perform. Default is 10 (OPTIONAL, UNCOMMONLY SPECIFIED)
#' @param debug This will print more useless information as it goes along. Only useful for troubleshooting problems. (OPTIONAL, UNCOMMONLY SPECIFIED)
#' @return The output of this function is: (1) the stage 1 (i.e. the exploratory stage) (stage1out), (2) the stage 2 model (gamstage2out or OpenMxstage2out), (3) the data used to run the models in the first and second stage (datamanipulationout). Use str() around the saved object to see the information (it is useful to specify the max.level at a time so that the information does not get overwhelming)
#' @import mgcv
#' @import plyr
#' @import zoo
#' @import reshape2
#' @import OpenMx
#' @import Rcpp
#' @export
#' @examples
#' 
#' #Load the example data set 1
#' data(exampledat1)
#' 
#' #Run Univariate DTVEM
#' #out=LAG("X",differntialtimevaryingpredictors=c("X"),outcome=c("X"),data=exampledat1,Time="Time",k=9,standardized=FALSE,ID="ID",predictionsend=10,predictionstart=1,independentpredictors=FALSE,software="OpenMx")

#@examples #NEED TO COME BACK TO PUT EXAMPLES IN WITH AN EXAMPLE DATA SET

LAG<-function(...,differntialtimevaryingpredictors=NULL,outcome=NULL,controlvariables=NULL,data=NULL,ID="ID",Time=NULL,k=10,k2=10,k3=3,k4=3,controllag=NULL,standardized=TRUE,predictionstart=NULL,predictionsend=NULL,predictionsinterval=NULL,software="OpenMx",independentpredictors=FALSE,minimumpracticalsignificance=NULL,gamma=1,minN=30,debug=FALSE,OpenMxStartingValues=.3,ResidualAnalysis="Group",blockdata=FALSE,rounddecimals=TRUE,maxintermediaterounds=10){
  #LOAD NECESSARY PACKAGES
  #library(mgcv) #USED FOR THE PRIMARY ANALYSES
  #library(plyr)
  #library(zoo)
  #library(reshape2)
  if(software=="OpenMx"){
    #require(OpenMx)
    if(mxVersion()[1]<2){
      stop("You are using an older version of OpenMx, you need to upgrade your OpenMx version to use it here.")
    }
  }
  
  input_list<-list(...) #GET THE NAMES OF THE VARIABLES
  varnames<-unlist(input_list) #UNLIST THE VARIABLE NAMES SO THAT THEY ARE IN A VECTOR INSTEAD OF A LIST
  numberofvars<-as.numeric(length(input_list)) #GET THE NUMBER OF VARIABLES
  if(sum(is.na(unique(data[,ID])))>0){ #CHECK TO SEE IF THE THERE ARE ANY MISSING ID Variables #
    stop("ERROR: At least one ID is missing. Missing data is not allowed in the ID column. Replace and re-run")
  }
  numberofpeople<-as.numeric(length(unique(data[,ID]))) #NUMBER OF PEOPLE = NUMBER OF UNIQUE IDs in DATAFRAME
  
  #Set the practical value positive and negatives
  if(is.null(minimumpracticalsignificance)){
    minimumpracticalsignificance=0
    minimumpracticalsignificanceneg=0
  }else{
    minimumpracticalsignificanceneg=minimumpracticalsignificance*-1
  }
  
  numberofknots<-k
  
  
  
  
  
  datamanipulationout=datamanipulation(...,numberofvars=numberofvars,input_list=input_list,differntialtimevaryingpredictors=differntialtimevaryingpredictors,outcome=outcome,controlvariables=controlvariables,data=data,ID="ID",Time=Time,controllag=controllag,standardized=standardized,predictionstart=predictionstart,predictionsend=predictionsend,predictionsinterval=predictionsinterval,beforeblock=TRUE)
  lengthcovariates=datamanipulationout$lengthcovariates
  namesofnewpredictorvariables=datamanipulationout$namesofnewpredictorvariables
  stage1out=stage1(differntialtimevaryingpredictors=differntialtimevaryingpredictors,outcome=outcome,predictionstart=predictionstart,predictionsend=predictionsend,predictionsinterval=predictionsinterval,namesofnewpredictorvariables=namesofnewpredictorvariables,laglongreducedummy=datamanipulationout$laglongreducedummy,gamma=gamma,numberofknots=numberofknots,k3=k3,controlvariables=controlvariables,debug=debug,minimumpracticalsignificance=minimumpracticalsignificance,minimumpracticalsignificanceneg=minimumpracticalsignificanceneg,lengthcovariates=lengthcovariates,blockdata=blockdata)
  predictionstart=stage1out$predictionstart
  predictionsend=stage1out$predictionsend
  predictionsinterval=stage1out$predictionsinterval
  
  if(isTRUE(rounddecimals)){
    rounddecimals=decimalplaces(datamanipulationout$Timelagsdummy$time)
  }
  
  #HELP THE USER DECIDE TO BLOCK THE DATA
  equalorunequal=unequaltoequal(input_list=input_list,data=data,ID=ID,Time=Time,stage1out=stage1out,rounddecimals=rounddecimals,numberofvars=numberofvars)
  
  
  #NEXT I NEED TO RE-COMPILE RAW DATA BY TIME BLOCKS AND RE-ESEMBLE
  if(blockdata!=FALSE|equalorunequal$unequalintervals){
    if(isTRUE(blockdata)){ #IF SET TO AUTOMATIC TIME BLOCKING
      #cat("Time blocks set to ",round(min(c(stage1out$minpeakvalley,stage1out$minpeakvalleydist)),rounddecimals),"\n")
      #blockdata<-round(min(c(stage1out$minpeakvalley,stage1out$minpeakvalleydist)),rounddecimals) #SET BLOCKING TO MIN PEAK/VALLEY OR DISTANCE BETWEEN PEAK/VALLEYS
      #cat("Time blocks set to ",2*round(stage1out$mintimenotsig,rounddecimals),"\n")
      #blockdata<-2*round(stage1out$mintimenotsig,rounddecimals) #SET BLOCKING TO SMALLEST NON-SIGNIFICANT DIFFERENCE
      blockdata=round(equalorunequal$lowerquartile,rounddecimals)
      cat(paste("Time blocks set to ",blockdata,"\n",sep=""))
    }else if(blockdata>0){
      cat(paste("Time blocks set to ",blockdata,"\n",sep=""))
    }else{
      blockdata=round(equalorunequal$lowerquartile,rounddecimals)
      cat(paste("Time blocks set to ",blockdata,"\n",sep=""))
    }
    datablocked=data
    datablocked$timeblock=ceiling(data[,Time]/blockdata)
    datablocked2=suppressWarnings((aggregate(datablocked,by=list(data[,ID],datablocked$timeblock),FUN=mean, na.rm=TRUE)))
    
    #JULY 10 2016 EDITION
    datablocked2$timeblock=datablocked2$timeblock*blockdata
    
    #COMMMENTED OUT ON JULY 10, 2016:
    #predictionstart<-1
    #predictionsend<-ceiling(predictionsend/blockdata)
    #predictionsinterval<-1
    #/END COMMENTED OUT ON JULY 10, 2016
    predictionstart=blockdata
    predictionsinterval=blockdata
    
    #print(predictionstart)
    #print(paste("predictionsend = ",predictionsend))
    #print(paste("blockdata = ",blockdata))
    #print(predictionsend)
    #print(predictionsinterval)
    Time="timeblock"
    #MAKE SURE THAT THE HIGHEST END VALUE CHANGES TOO WITH NEW LAG TIMES
    
    #TO DO
    #CREATE DUMMY DATA BASED ON THE UNIQUE TIME VALUES AND MERGE
    
    #JULY 10, 2016: 
    #OLD CODE:uniquetimeblocks=unique(datablocked$timeblock)
    #NEW CODE:
    uniquetimeblocks=unique(datablocked2$timeblock)
    #/NEW CODE
    
    dummyblocked=matrix(NA,nrow=length(uniquetimeblocks)*numberofpeople,ncol=2)
    dummyblocked=data.frame(dummyblocked)
    names(dummyblocked)=c(ID,Time)
    dummyblocked[,ID]=sort(rep(unique(data[,ID]),length(uniquetimeblocks)))
    dummyblocked[,Time]=rep(uniquetimeblocks,numberofpeople)
    datablocked3=merge(dummyblocked,datablocked2,all.x = TRUE,by=c(ID,Time))
    
    datamanipulationoutold=datamanipulationout #SAVE THE LAST DATA MANIPULATION OUT
    stage1outold=stage1out
    #THEN SUMMARIZE THE DEGREE OF MISSING DATA
    cat("Next, we describe the percentage of missingness after the data organization for each pair of predictors and outcomes\n")
    missingmat=matrix(NA,nrow=(length(outcome)*length(differntialtimevaryingpredictors)),ncol=3)
    missingcounter=0
    for(mmmmmm in 1:length(outcome)){
      for(mmmmmmm in 1:length(differntialtimevaryingpredictors)){
        missingcounter=missingcounter+1
        predictoroutcomecomb=datablocked3[,c(differntialtimevaryingpredictors[mmmmmmm],outcome[mmmmmm])]
        missingness=round((1-sum(!is.na(rowSums(predictoroutcomecomb)))/nrow(predictoroutcomecomb))*100,2)
        missingmat[missingcounter,1]=missingness
        missingmat[missingcounter,2]=differntialtimevaryingpredictors[mmmmmmm]
        missingmat[missingcounter,3]=outcome[mmmmmm]
        cat(paste("\t",missingness,"% of the data between predictor ",differntialtimevaryingpredictors[mmmmmmm]," and ",outcome[mmmmmm],sep="")," is missing\n")
      }
    }
    missingmat=data.frame(missingmat)
    names(missingmat)=c("PercentageMissing","Predictor","Outcome")
    
    numberofknots=k2
    
    datamanipulationout=datamanipulation(...,numberofvars=numberofvars,input_list=input_list,differntialtimevaryingpredictors=differntialtimevaryingpredictors,outcome=outcome,controlvariables=controlvariables,data=datablocked3,ID="ID",Time=Time,controllag=controllag,standardized=standardized,predictionstart=predictionstart,predictionsend=predictionsend,predictionsinterval=predictionsinterval,beforeblock = FALSE)
    cat("Now re-running stage 1 with the re-blocked time series","\n")
    stage1out=stage1(differntialtimevaryingpredictors=differntialtimevaryingpredictors,outcome=outcome,predictionstart=predictionstart,predictionsend=predictionsend,predictionsinterval=predictionsinterval,namesofnewpredictorvariables=namesofnewpredictorvariables,laglongreducedummy=datamanipulationout$laglongreducedummy,gamma=gamma,numberofknots=numberofknots,k3=k3,controlvariables=controlvariables,debug=debug,minimumpracticalsignificance=minimumpracticalsignificance,minimumpracticalsignificanceneg=minimumpracticalsignificanceneg,lengthcovariates=lengthcovariates)
    reblocklist=list("missingmat"=missingmat,"blockdata"=blockdata,"rawreblocked"=datablocked3)
    
    
    oldpred <- predict(stage1outold$mod, stage1out$pdat, type = "terms", se.fit = TRUE)
    newpred <- predict(stage1out$mod, stage1out$pdat, type = "terms", se.fit = TRUE)
    
    cat("The next output includes the correlation of the predictions from DTVEM stage 1 before blocking and DTVEM stage 1 after blocking.\n")
    for(j in 1:length(stage1out$vectorofnames)){
      cat(paste("Correlation between pre-blocked",stage1out$vectorofnames[j],"is:",cor(oldpred$fit[,j],newpred$fit[,j]),"\n",sep=""))
    }
    
  }else{
    datamanipulationoutold=NULL #IF FALSE MAKE THE OLD STATEMENT NULL SO IT DOES NOT CAUSE ERRORS LATER
    stage1outold=NULL
    missingmat=NULL
    reblocklist=NULL
    
  }
  Timelagsdummy=datamanipulationout$Timelagsdummy
  laglongreducedummy=datamanipulationout$laglongreducedummy
  variablenamesonlysigall=stage1out$variablenamesonlysigall
  lengthcovariates=datamanipulationout$lengthcovariates
  namesofnewpredictorvariables=datamanipulationout$namesofnewpredictorvariables
  
  #NOW GO TO STAGE 2
  cat(paste("DTVEM stage 1 identified the following variables as potential peaks or valleys:",sort(paste(paste(stage1out$variablenamesonlysigall,collapse = ", ")))),"\n")
  
  #REMOVE THE LAGS THAT ARE NOT IN Timelagsdummy
  namesinTimelagsdummy=names(Timelagsdummy)
  variablenamesonlysigall=variablenamesonlysigall[variablenamesonlysigall%in%namesinTimelagsdummy] #REMOVE ALL LAGS THAT ARE NOT PRESENT IN THE COLUMN NAMES OF TIME LAGS DUMMY
  
  if(length(variablenamesonlysigall)>1){
    variablenamesonlysigall<-variablenamesonlysigall[colSums(!is.na(Timelagsdummy[,variablenamesonlysigall]),na.rm=TRUE)>=minN]
  }else{
    variablenamesonlysigall<-variablenamesonlysigall[sum(!is.na(Timelagsdummy[,variablenamesonlysigall]),na.rm=TRUE)>=minN]
  }
  
  
  ##################
  #RUN STAGE 2
  if(software=="gam"){ #STAGE 2 WITH GAM
    gamstage2out=gamstage2(Timelagsdummy=Timelagsdummy,variablenamesonlysigall=variablenamesonlysigall,independentpredictors=independentpredictors,k3=k3,software=software)
    controlswidelong=gamstage2out$controlswidelong
  }else{
    gamstage2out=NULL
  }
  if(software=="OpenMx"){ #STAGE 2 with OpenMx
    OpenMxstage2out=OpenMxstage2(Timelagsdummy=Timelagsdummy,predictionstart=predictionstart,predictionsend=predictionsend,predictionsinterval=predictionsinterval,variablenamesonlysigall=variablenamesonlysigall,independentpredictors=independentpredictors,k3=k3,numberofvars=numberofvars,OpenMxStartingValues=OpenMxStartingValues,ResidualAnalysis=ResidualAnalysis,varnames=varnames,outcome=outcome,numberofpeople=numberofpeople)
    controlswidelong=OpenMxstage2out$controlswidelong
  }else{
    OpenMxstage2out=NULL
  }
  # stage1(differntialtimevaryingpredictors=differntialtimevaryingpredictors,outcome=outcome,predictionstart=predictionstart,predictionsend=predictionsend,predictionsinterval=predictionsinterval,namesofnewpredictorvariables=namesofnewpredictorvariables,laglongreducedummy=datamanipulationout$laglongreducedummy,gamma=gamma,numberofknots=numberofknots,k3=k3,controlvariables=controlvariables,debug=debug,minimumpracticalsignificance=minimumpracticalsignificance,minimumpracticalsignificanceneg=minimumpracticalsignificanceneg,lengthcovariates=lengthcovariates,blockdata=blockdata)
  if(software=="hybrid"){ #STAGE 2 with GAM THEN OPENMX
    #RUN STAGE 2 WITH GAM THEN OPENMX
    gamstage2out=gamstage2(Timelagsdummy=Timelagsdummy,variablenamesonlysigall=variablenamesonlysigall,independentpredictors=independentpredictors,k3=k3,software=software)
    controlswidelong=gamstage2out$controlswidelong
    if(length(controlswidelong)>0){ #IF THERE ARE ANY VARIABLES THAT ARE IDENTIFIED FROM GAM STAGE 2, RE-RUN THEM IN OPENMX
      variablenamesonlysigall=controlswidelong
    }
    OpenMxstage2out=OpenMxstage2(Timelagsdummy=Timelagsdummy,predictionstart=predictionstart,predictionsend=predictionsend,predictionsinterval=predictionsinterval,variablenamesonlysigall=variablenamesonlysigall,independentpredictors=independentpredictors,k3=k3,numberofvars=numberofvars,OpenMxStartingValues=OpenMxStartingValues,ResidualAnalysis=ResidualAnalysis,varnames=varnames,outcome=outcome,numberofpeople=numberofpeople)
    controlswidelong=OpenMxstage2out$controlswidelong
    if(length(controlswidelong)>0){
      message("OpenMx did either: /n(1) Not converge /n(2)Not contain reliable estimates/nReturning estimates from GAM")
      OpenMxstage2out=NULL
      controlswidelong=variablenamesonlysigall
    }
  }
  
  if((length(controlswidelong)>0)){
    cat(paste("Completed stage 2 of DTVEM (wide format). Now passing to Stage 1.5. Controlling for the following lags in the varying-coefficient model: ", paste(controlswidelong,collapse=", ")),"\n")
  }
  
  ##################
  #STEP 1.5 ->2 LOOP
  iiii=0
  newfeasiblepeaksWLvalleyssig=c()
  if (length(controlswidelong)>0){ #ONLY ENTER THIS STAGE 
    while(iiii<maxintermediaterounds){ #THIS IS USED TO LOOP THROUGH EVERYTHING THIS MAKES SURE THAT IT IS NOT STUCK IN AN INFINITE LOOP
      iiii=iiii+1
      
      #DATA MANIPULATION TO ADD CONTROL VARIABLE LAG TIMES
      #NOW TRYING TO ADD CONTROL VARIABLE LAG TIMES TO THE LONG FORMAT
      laglongcolumnnames=colnames(laglongreducedummy)#USEFUL TO CHECK IF THE VARIABLES HAVE ALREADY BEEN CREATED
      controlswidelongcontrolnames=paste(controlswidelong,"control",sep="")
      lengthcovariates=lengthcovariates+length(controlswidelongcontrolnames)
      newcontrolswidelong=controlswidelong[which(!(controlswidelongcontrolnames%in%laglongcolumnnames))]
      if(length(newcontrolswidelong)==0){
        break
      }
      if(debug==TRUE){
        print(paste("newcontrolswidelong==",newcontrolswidelong))
      }
      
      if(length(newcontrolswidelong)>0){
        controlmatrix=matrix(NA,nrow=datamanipulationout$laglongmatrixlength*length(outcome),ncol=length(newcontrolswidelong)) #CREATE A MATRIX FOR THE CONTROLS
        for(cc in 1:length(newcontrolswidelong)){
          controlmatrix[,cc]=Timelagsdummy[,paste(newcontrolswidelong[cc])]
        } 
        controlmatrix=data.frame(controlmatrix)
        names(controlmatrix)[1:length(newcontrolswidelong)]=paste(newcontrolswidelong,"control",sep="")
        for(oo in 1:length(outcome)){
          onext=(oo-1)*datamanipulationout$laglongmatrixlength+1
          onextnext=oo*datamanipulationout$laglongmatrixlength
          lnext=(oo-1)*nrow(datamanipulationout$laglongreducedummybackup)/length(outcome)+1
          lnextnext=(oo)*nrow(datamanipulationout$laglongreducedummybackup)/length(outcome)
          laglongtemp=cbind(datamanipulationout$laglongreducedummybackup[lnext:lnextnext,],controlmatrix[onext:onextnext,])
          if(oo==1){
            laglong2=laglongtemp
          }else{
            laglong2=rbind(laglongtemp,laglongtemp)
          }
        }
        
        laglongreducedummy<- laglong2[laglong2[,3]>0,] #DELETING CONCURRENT TIMES
        if(predictionsend>0){
          laglongreducedummy <- laglongreducedummy[laglongreducedummy[,3]<=predictionsend,] #DELETING CONCURRENT TIMES
        }
        if(!is.null(predictionsend)){
          laglongreducedummy <- laglongreducedummy[laglongreducedummy[,3]<=predictionsend,] #DELETING TIMES LESS THEN THE PREDICTIONS END
          #print(paste("the number of rows in laglongreducedummy is ", nrow(laglongreducedummy)))
        }
        
        #2015.07.24
        #OLD CODE: laglongreducedummy <- laglongreducedummy[!(laglongreducedummy[,3]%in%unique(na.omit(as.numeric(unlist(strsplit(unlist(stage1out$variablenamesonlysigall), "[^0-9]+")))))),] #EXTRACT THE TIMES THAT ARE BEING CONTROLLED FOR AND DELETE THEM FROM THE TIME SERIES
        
        laglongreducedummy <- laglongreducedummy[!(laglongreducedummy[,3]%in%unique(na.omit(as.numeric(unlist(as.numeric(gsub(".*lag","",stage1out$variablenamesonlysigall))))))),]#July 10, 2016, NEW CODE
        
        
        names(laglongreducedummy)[(ncol(laglongreducedummy)-length(newcontrolswidelong)+1):ncol(laglongreducedummy)]=paste(newcontrolswidelong,"control",sep="")
        #/END DATA MANIPULATION FOR STAGE 1.5
        
        allcontrolswidelong=c(controlvariables,paste(controlswidelong,"control",sep="")) #NOTE THAT THIS INCLUDES THE REGULAR CONTROL VARIABLES SPECIFIED FROM THE BEGINNING AND THE NEW CONTROL VARIABLES IDENTIFIED AS SIGNIFICANT LAG POINTS
        
        #NEXT I JUST NEED TO RUN THE SCRIPT TO SEE WHICH LAGS ARE PEAKS
        #THE ONLY THING I DO HERE IS CHANGE THE CONTROL VARIABLES TO allcontrolswidelong
        tryintermediate=try(intermediatestageout<-stage1(controlvariables=allcontrolswidelong,differntialtimevaryingpredictors=differntialtimevaryingpredictors,outcome=outcome,predictionstart=predictionstart,predictionsend=predictionsend,predictionsinterval=predictionsinterval,namesofnewpredictorvariables=namesofnewpredictorvariables,laglongreducedummy=laglongreducedummy,gamma=gamma,numberofknots=k4,k3=k3,debug=debug,minimumpracticalsignificance=minimumpracticalsignificance,minimumpracticalsignificanceneg=minimumpracticalsignificanceneg,intermediatestage=TRUE,lengthcovariates=lengthcovariates),silent=TRUE)        
        if(try(summary(tryintermediate)[2],silent=TRUE)=="try-error"){ #IF MODEL DID NOT RUN SUCCESSFULLY RUN IN GAMM
          variablenamesonlysigall=controlswidelong
          intermediatestageout=NULL
        }else{
          variablenamesonlysigall<-sort(unique(c(controlswidelong,intermediatestageout$variablenamesonlysigall))) #ADD THE NEWLY IDENTIFIED VARIABLES TO THE VARIABLESTOBETESTED
        }
        
        #THERE IS AN ERROR HERE WITH PERIODS IN THE NAME, NEED TO EDIT HERE IT ALSO FAILS IN THE GAMSTAGE2OUT
        
        if(length(variablenamesonlysigall)>1){
          variablenamesonlysigall<-variablenamesonlysigall[colSums(!is.na(Timelagsdummy[,variablenamesonlysigall]),na.rm=TRUE)>=minN]
        }else{
          variablenamesonlysigall<-variablenamesonlysigall[sum(!is.na(Timelagsdummy[,variablenamesonlysigall]),na.rm=TRUE)>=minN]
        }
        
        #RUN INTERMEDIATE CONFIRMATORY STEP
        if(software=="gam"){
          gamstage2out=gamstage2(Timelagsdummy=Timelagsdummy,variablenamesonlysigall=variablenamesonlysigall,independentpredictors=independentpredictors,k3=k3,software=software)
          controlswidelong=gamstage2out$controlswidelong
        }else{
          gamstage2out=NULL
        }
        if(software=="OpenMx"){
          OpenMxstage2out=OpenMxstage2(Timelagsdummy=Timelagsdummy,predictionstart=predictionstart,predictionsend=predictionsend,predictionsinterval=predictionsinterval,variablenamesonlysigall=variablenamesonlysigall,independentpredictors=independentpredictors,k3=k3,numberofvars=numberofvars,OpenMxStartingValues=OpenMxStartingValues,ResidualAnalysis=ResidualAnalysis,varnames=varnames,outcome=outcome,numberofpeople=numberofpeople)
          controlswidelong=OpenMxstage2out$controlswidelong
        }else{
          OpenMxstage2out=NULL
        }
        
        if(software=="hybrid"){ #STAGE 2 with GAM THEN OPENMX
          #RUN STAGE 2 WITH GAM THEN OPENMX
          gamstage2out=gamstage2(Timelagsdummy=Timelagsdummy,variablenamesonlysigall=variablenamesonlysigall,independentpredictors=independentpredictors,k3=k3,software=software)
          controlswidelong=gamstage2out$controlswidelong
          if(length(controlswidelong)>0){ #IF THERE ARE ANY VARIABLES THAT ARE IDENTIFIED FROM GAM STAGE 2, RE-RUN THEM IN OPENMX
            variablenamesonlysigall=controlswidelong
          }
          OpenMxstage2out=OpenMxstage2(Timelagsdummy=Timelagsdummy,predictionstart=predictionstart,predictionsend=predictionsend,predictionsinterval=predictionsinterval,variablenamesonlysigall=variablenamesonlysigall,independentpredictors=independentpredictors,k3=k3,numberofvars=numberofvars,OpenMxStartingValues=OpenMxStartingValues,ResidualAnalysis=ResidualAnalysis,varnames=varnames,outcome=outcome,numberofpeople=numberofpeople)
          controlswidelong=OpenMxstage2out$controlswidelong
          if(length(controlswidelong)>0){
            message("OpenMx did either: /n(1) Not converge /n(2)Not contain reliable estimates/nReturning estimates from GAM")
            OpenMxstage2out=NULL
            controlswidelong=variablenamesonlysigall
          }
        }
        
        numberofpasses<-iiii+1
        cat(paste("This is the #",numberofpasses," out of a possible ",maxintermediaterounds," passes",sep=""),"\n")
      }
    }
  }
  
  
  cat("Completed loop between 1.5 and 2\n")
  cat("DTVEM analysis completed,congradulations!\n")
  cat("Contact the author - Nick Jacobson: njacobson88@gmail.com if you have any questions.\n")
  if(software=="gam"){
    print(summary(gamstage2out$widemodelout$gam))
  }
  if(software=="OpenMx"){
    print(summary(OpenMxstage2out$multisubjectRun))
    print(OpenMxstage2out$OpenMxout)
  }
  if(software=="hybrid"){
    if(OpenMxstage2out)
    print(summary(OpenMxstage2out$multisubjectRun))
    print(OpenMxstage2out$OpenMxout)
  }
  if(blockdata!=FALSE){
    cat(paste("Note that each lag represents an increase in",blockdata,"time units"),"\n")
  }
  
  predictorsoutcomelist=list("outcome"=outcome,"differntialtimevaryingpredictors"=differntialtimevaryingpredictors)
  
  returnlist=list("datamanipulationoutold"=datamanipulationoutold,"stage1outold"=stage1outold,"datamanipulationout"=datamanipulationout,"stage1out"=stage1out,"reblocklist"=reblocklist,"stage1out"=stage1out,"gamstage2out"=gamstage2out,"OpenMxstage2out"=OpenMxstage2out,"predictorsoutcomelist"=predictorsoutcomelist,"intermediatestageout"=intermediatestageout)
  class(returnlist)<-"DTVEM"
  return(returnlist)
}