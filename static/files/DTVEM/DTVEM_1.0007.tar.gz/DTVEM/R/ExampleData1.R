#' Simulated Example Dataset 1: Univariate
#'
#' A simulated example data set. This data set contains 100 persons, 14 time points, 35% missingness, simulated with an AR(1,2,3) process wherein AR(1) = .25, AR(2)=-.25, and AR(3)=.3
#'
#' \itemize{
#'   \item ID. The ID variable representing each person.
#'   \item Time. The Time variable representing times 1 - 14.
#'   \item X. The variable of interest
#' }
#'
#' @docType data
#' @keywords datasets
#' @name exampledat1
#' @usage data(exampledat1)
#' @format A data frame with 1400 rows and 3 variables
NULL