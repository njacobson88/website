StateSpaceFunction<-function(variablenamestotest=variablenamestotest,OpenMxmatlength=OpenMxmatlength,lengthoflags=lengthoflags,Timelagsdummy=Timelagsdummy,predictionstart=predictionstart,predictionsend=predictionsend,predictionsinterval=predictionsinterval,variablenamesonlysigall=variablenamesonlysigall,independentpredictors=independentpredictors,k3=k3,numberofvars=numberofvars,OpenMxStartingValues=OpenMxStartingValues,ResidualAnalysis=ResidualAnalysis,varnames=varnames,outcome=outcome,numberofpeople=numberofpeople){
  #NEED TO PARSE APART variablenamesonlysigall
  split1=strsplit(variablenamestotest,"lagon")
  split1mat=matrix(unlist(split1),nrow=length(split1),byrow=TRUE)
  split2=strsplit(split1mat[,2],"lag")
  split2mat=cbind(split1mat[,1],matrix(unlist(split2),nrow=length(split2),byrow=TRUE))
  split2dataframe=data.frame(split2mat)
  names(split2dataframe)=c("Predictor","Outcome","lag")
  #NOW NEED TO CREATE BLOCK MATRIX SCHEME
  split2dataframe$lag=as.factor(as.numeric(as.character(split2dataframe$lag))/predictionsinterval) #ADDED JULY 7, 2016
  
  Amat=matrix(0,ncol=OpenMxmatlength,nrow=OpenMxmatlength)
  #input_list
  #Creating matrices rows and columns for Matrix A
  rows=list()
  columns=list()
  diagonallagrow=list()
  diagonallagcol=list()
  for(ooo in 1:length(varnames)){
    predmatch=(split2dataframe$Predictor==varnames[ooo])*1
    outmatch=(split2dataframe$Outcome==varnames[ooo])*1
    rows[[ooo]]=1*outmatch+lengthoflags*(ooo-1)*outmatch
    #JULY 7, 2016 OLD CODE: columns[[ooo]]=1*predmatch+lengthoflags*(ooo-1)*predmatch+as.numeric(levels(split2dataframe$lag))[split2dataframe$lag]*predmatch
    columns[[ooo]]=1*predmatch+lengthoflags*(ooo-1)*predmatch+as.numeric(levels(split2dataframe$lag))[split2dataframe$lag]*predmatch #columns[[ooo]]=1*predmatch+lengthoflags*(ooo-1)*predmatch+split2dataframe$lag*predmatch
    diagonallagrow[[ooo]]=2:(lengthoflags)+lengthoflags*(ooo-1)
    diagonallagcol[[ooo]]=1:(lengthoflags-1)+lengthoflags*(ooo-1)
  }
  rowmat=matrix(unlist(rows),nrow=length(varnames),byrow=TRUE)
  rowlist=colSums(rowmat)
  columnmat=matrix(unlist(columns),nrow=length(varnames),byrow=TRUE)
  columnlist=colSums(columnmat)-1
  
  Amatfr=matrix(FALSE,ncol=OpenMxmatlength,nrow=OpenMxmatlength)#Matrix for elements in Matrix A that are FREE
  Amat=matrix(FALSE,ncol=OpenMxmatlength,nrow=OpenMxmatlength)#Matrix for the values of the elements in Matrix A
  Alab=matrix(NA,ncol=OpenMxmatlength,nrow=OpenMxmatlength) #Matrix for all of the labels in Matrix A
  for(ooo in 1:length(rowlist)){
    Amatfr[rowlist[ooo],columnlist[ooo]]=TRUE
    Amat[rowlist[ooo],columnlist[ooo]]=OpenMxStartingValues
    Alab[rowlist[ooo],columnlist[ooo]]=gsub("\\.", "_",paste(variablenamestotest[ooo])) #ADDED JULY 6, 2016
  }
  
  diagonallistrow=unlist(diagonallagrow)
  diagonallistcolumn=unlist(diagonallagcol)
  
  for(ooo in 1:length(diagonallistrow)){
    Amat[diagonallistrow[ooo],diagonallistcolumn[ooo]]=1 #CREATE DIAGONAL CONSTRAINTS FOR ALL LAGS
  }
  
  
  
  Cmat=matrix(0,ncol=OpenMxmatlength,nrow=numberofvars) #C MATRIX
  Qmatfr=rep(FALSE,OpenMxmatlength) #Q Matrix Free/Fixed Elements
  Qmat=rep(0,OpenMxmatlength) #Q Matrix Values
  Qlab=rep(NA,OpenMxmatlength) #Q matrix labels
  for(ooo in 1:numberofvars){
    oooo=((ooo-1)*lengthoflags+1)
    Cmat[ooo,oooo]=1
    Qmatfr[oooo]=TRUE
    Qmat[oooo]=5
    Qlab[oooo]=paste(varnames[ooo],"resid",sep="")
  }
  Cdimnames=list(varnames, paste("F",1:OpenMxmatlength,sep=""))
  
  #6.11.2015: MAY WANT TO ADD RESIDUALS FOR TIME EFFECTS IN TIMELAGSDUMMY
  #NOT NEEDED IN MGCV BECAUSE IT IS MODELED AS A SPLINE COVARIATE
  Timelagsdummyresid=Timelagsdummy
  if(ResidualAnalysis!=FALSE){ #NOTE THAT THIS IS NEW AND THIS VARIABLE HAS NOT BEEN CREATED -- EXPLORATORY CODE
    Timelagsdummyresid$IDf=factor(Timelagsdummyresid$ID)
    if(ResidualAnalysis=="Group"){ #GROUP IS JUST FOR THE TIME MODELING OF THE WHOLE GROUP
      for(i in 1:length(outcome)){
        cat("Removing group-based time of residuals\n")
        timemodel=as.formula(paste(outcome[i],"lag0~s(time,k=",k3,")",sep="")) #s(time,IDf,bs='fs')
        timemodelout=gam(timemodel,data=Timelagsdummyresid)
        Timelagsdummyresid[!is.na(Timelagsdummyresid[,paste(outcome[i],"lag0",sep="")]),paste(outcome[i],"lag0",sep="")]=residuals(timemodelout) #REPLACE ALL NON-MISSING OUTCOME VALUES WITH RESIDUALS
      }
    }else{
      for(i in 1:length(outcome)){
        cat("Run analysis on residuals aftect accounting for individual both group and individual time trends. This option can take a while, set ResidaulAnalysis = 'Group' to speed it up\n")
        timemodel=as.formula(paste(outcome[i],"lag0~s(time)+s(time,IDf,bs='fs',k=",k3,")",sep="")) #K set at 6 because large basis are a large problem here, WILL NOT RUN WITH A LARGE NUMBER
        timemodelout=gam(timemodel,data=Timelagsdummyresid)
        Timelagsdummyresid[!is.na(Timelagsdummyresid[,paste(outcome[i],"lag0",sep="")]),paste(outcome[i],"lag0",sep="")]=residuals(timemodelout)
      }
    }
  }
  
  
  indivmodels <- list()
  for(i in 1:numberofpeople){
    #THIS CREATES A MODEL FOR EACH SUBJECT
    idlist=unique(Timelagsdummyresid$ID)
    tempdata=data.frame(Timelagsdummyresid[Timelagsdummyresid$ID==idlist[i]&Timelagsdummyresid$Dummy1==1,paste(varnames,"lag0",sep="")]) #SELECT ROWS WITH MATCHING ID AND DUMMY = 1 because we only want one repeated column in case multivariate outcome is selected by user
    names(tempdata)=varnames
    
    indivmodels[[i]]<-mxModel(model=paste("s",i,sep=""),
                              mxMatrix("Full", OpenMxmatlength, OpenMxmatlength, Amatfr, Amat, name="A",labels=Alab),#,lbound=-2,ubound=2),
                              mxMatrix("Zero", OpenMxmatlength, numberofvars, name="B"),
                              mxMatrix("Full", numberofvars, OpenMxmatlength, FALSE,Cmat, name="C", dimnames=Cdimnames),
                              mxMatrix("Zero", numberofvars, numberofvars, name="D"),
                              mxMatrix("Diag", OpenMxmatlength, OpenMxmatlength, Qmatfr, Qmat, name="Q",labels=Qlab),
                              mxMatrix("Zero", numberofvars, numberofvars, name="R"),
                              mxMatrix("Zero", OpenMxmatlength, 1, name="x0"),
                              mxMatrix("Diag", OpenMxmatlength, OpenMxmatlength, FALSE, 1, name="P0"),
                              mxMatrix("Zero", numberofvars, 1, name="u"),
                              mxData(observed=tempdata, type="raw"),
                              mxExpectationStateSpace("A", "B", "C", "D", "Q", "R", "x0", "P0", "u"),
                              mxFitFunctionML()
    )
  }
  
  
  modnames=paste(paste("s", 1:numberofpeople, sep=""), "fitfunction", sep=".")
  
  multisubject <- mxModel("multisujbject",
                           indivmodels,
                           mxFitFunctionMultigroup(modnames))
  
  multisubjectRun <- mxTryHard(multisubject) #works!
  print(summary(multisubjectRun))
  
  OpenMxout<-summary(multisubjectRun)$parameters
  OpenMxout$tstat<-OpenMxout$Estimate/OpenMxout$Std.Error
  OpenMxout$pvalue<-(1-pnorm(abs(OpenMxout$tstat)))*2
  OpenMxout$sig<-OpenMxout$pvalue<.05
  
  OpenMxout<-OpenMxout[1:length(variablenamestotest),]
  OpenMxout<-OpenMxout[order(OpenMxout$name),]
  
  OpenMxreturnlist=list("multisubject"=multisubject,"multisubjectRun"=multisubjectRun,"OpenMxout"=OpenMxout)
  return(OpenMxreturnlist)
  
}