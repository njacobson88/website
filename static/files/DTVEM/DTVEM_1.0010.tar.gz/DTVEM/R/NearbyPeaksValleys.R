#' Nearby Peaks and Valleys Function
#' 
#' Looks for values that are nearby the peaks and valleys and are not significantly different. Note that all values should be specified, no values should be left to the defaults.
#' @param values This is the vector of peaks or valleys to investigate
#' @param lowerCI The lower confidence interval of the variable of interest
#' @param upperCI The upper confidence interval of the variable of interest
#' @param timepred This is the time prediction values from the start to the end of the predictions in intervals dictated by the intervals
#' @param updown This tells the function whether to look up for the nearby values or down (1 for up, -1 for down)
#' @param j This tells the function which variable is being investigated
#' @param predictionsend The end of the time predictions
#' @return The output of this function will be a vector of nearby peaks or valleys that are not significantly different from the inputted values
#' @export

#' 
#THIS CODE IS USED TO IDENTIFY NEARBY PEAKS/VALLEYS
nearbypeakvalleys=function(values=peaks,lowerCI=lowerboundvcfx,upperCI=upperboundvcfx,timepred=timepred,updown=1,j=j,predictionsend=predictionsend){
  jj=0#TEMP VARIABLE USED FOR COUNT
  while(jj<length(timepred)){ #THIS LOOP CONTINUES UNTIL THE GREATEST NUMBER OF TIME POINTS IS REACHED -- OR IF ALL HIGHER VALUES HAVE BEEN IDENTIFIED
    jj=jj+1 #IINCREASE THE COUNT
    if(jj==1){
      #print(paste("values = ",values))
      
      #Look at the next closest point to the value in the time vector matrix in the same direction
      nearvaluesup=values+(jj*updown) 
      
      #Remove the values and test values if the test value index is below 1
      values=values[nearvaluesup>0]
      nearvaluesup=nearvaluesup[nearvaluesup>0]
      
      #print(paste("nearvaluesup = ",nearvaluesup))
      intimeseries=(timepred[nearvaluesup]>0&timepred[nearvaluesup]<predictionsend)#ARE THE VALUES IN THE TIME SERIES?
      intimeseries[is.na(intimeseries)]=FALSE #REPLACE ANY MISSING VALUES WITH FALSE
      possiblenearvaluesup=nearvaluesup[intimeseries] #THIS MAKES SURE THAT THE VALUES BEING SELECTED ARE NOT 0 OR GREATER THAN THE TIME SERIES
      #print(paste("possiblenearvaluesup = ",possiblenearvaluesup))
      valuescomparisonup=values[intimeseries] #THIS MAKES SURE THAT THE COMPARISON valuesS ARE NOT NEGATIVELY AFFECTED
      #print(paste("valuescomparisonup = ",valuescomparisonup))
      valuesscomparisonuplowerCI=lowerCI[valuescomparisonup,j] #GRAB THE valuesS UPPER CI
      #print(paste("valuesscomparisonuplowerCI = ",valuesscomparisonuplowerCI))
      #print(paste("valuesscomparisonuplowerCI = ",valuesscomparisonuplowerCI))
      valuesscomparisonupupperCI=upperCI[valuescomparisonup,j] #THE UPPER CONFIDENCE INTERVAL OF THE REFERENCE VALUE
      #print(paste("valuesscomparisonupupperCI = ",valuesscomparisonupupperCI))
      valuestotestlowerCI=lowerCI[possiblenearvaluesup,j]
      #print(paste("valuestotestlowerCI = ",valuestotestlowerCI))
      valuestotestupperCI=upperCI[possiblenearvaluesup,j] #THE UPPER CONFIDENCE INTERVAL OF THE TEST VALUE
      #print(paste("valuestotestupperCI = ",valuestotestupperCI))
      nearvaluesupsigdiff=possiblenearvaluesup[valuesscomparisonuplowerCI<valuestotestupperCI&valuesscomparisonupupperCI>valuestotestlowerCI] #SEE IF THE valuesS LOWER CI and the Nearby valuesS UPPER CI OVERLAP -- IF SO KEEP IT FOR LATER
      nearvaluesupsigdiffall=nearvaluesupsigdiff
    } else{
      valuesreference=valuescomparisonup[valuesscomparisonuplowerCI<upperCI[possiblenearvaluesup,j]&valuesscomparisonupupperCI>lowerCI[possiblenearvaluesup,j]] 
      #Look at the next closest point to the value in the time vector matrix in the same direction
      nearvaluesup=valuesreference+(jj*updown)
      
      #Remove the reference values and test values if the test value index is below 1
      valuesreference=valuesreference[nearvaluesup>0]
      nearvaluesup=nearvaluesup[nearvaluesup>0]
      
      intimeseries=(timepred[nearvaluesup]>0&timepred[nearvaluesup]<predictionsend)#ARE THE VALUES IN THE TIME SERIES?
      intimeseries[is.na(intimeseries)]=FALSE #REPLACE ANY MISSING VALUES WITH FALSE
      possiblenearvaluesup=nearvaluesup[intimeseries] #THIS MAKES SURE THAT THE VALUES BEING SELECTED ARE NOT 0 OR GREATER THAN THE TIME SERIES
      valuescomparisonup=valuesreference[intimeseries] #THIS MAKES SURE THAT THE COMPARISON valuesS ARE NOT NEGATIVELY AFFECTED
      valuesscomparisonuplowerCI=lowerCI[valuescomparisonup,j] #GRAB THE valuesS UPPER CI
      valuesscomparisonupupperCI=upperCI[valuescomparisonup,j]
      valuestotestlowerCI=lowerCI[possiblenearvaluesup,j]
      valuestotestupperCI=upperCI[possiblenearvaluesup,j]
      nearvaluesupsigdiff=possiblenearvaluesup[valuesscomparisonuplowerCI<valuestotestupperCI&valuesscomparisonupupperCI>valuestotestlowerCI] #SEE IF THE valuesS LOWER CI and the Nearby valuesS UPPER CI OVERLAP -- IF SO KEEP IT FOR LATER
      nearvaluesupsigdiffall=c(nearvaluesupsigdiffall,nearvaluesupsigdiff)
    }   
    if(length(nearvaluesupsigdiff)==0){
      break
    }
  }
  return(nearvaluesupsigdiffall)
}