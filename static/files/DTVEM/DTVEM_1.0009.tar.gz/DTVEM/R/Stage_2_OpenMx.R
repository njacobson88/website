#' Stage 2 OpenMx: State-Space Confirmatory Model
#' 
#' PLEASE USE THE LAG FUNCTION RATHER THAN THIS UNLESS YOU WOULD LIKE TO SPECIFY THIS MANUALLY.
#' @param ... A list of variable names used in the function e.g. "X","Y" (REQUIRED)
#' @param Timelagsdummy The Timelagsdummy data frame
#' @param k3 The number of k selection points used in the model for the time spline (NOTE THAT THIS CONTROLS FOR TIME TRENDS OF THE POPULATION)  (see ?choose.k in mgcv package for more details). Default is 3. (OPTIONAL)
#' @param predictionstart The differential time value to start with, default is NULL, and the lowest time difference in the time series will be used (use lower value if you're first value if you're interested in a smaller interval prediction) e.g. predictionstart = 1. If this is not specified and using a continuous time model, make sure to set blockdata = TRUE so that it will be automatically chosen. (OPTIONAL)
#' @param predictionsend The differential time value to end with. This means how long you want your largest time difference in the study to be (i.e. if you wanted to predict up to allow time predictions up to 24 hours and your time intervals were specified in hours, you would set predictionsend = 24). If this is not specified and using a continuous time model, make sure to set blockdata = TRUE so that it will be automatically chosen. (OPTIONAL)
#' @param predictionsinterval The intervals to predict between differential time points. If using discrete time do you want the intervals to be specified every discrete interval, if so set this to 1. If this is not specified and using a continuous time model, make sure to set blockdata = TRUE so that it will be automatically chosen. (OPTIONAL)
#' @param variablenamesonlysigall The variables to be included in the confirmatory model
#' @param independentpredictors This is whether or not the wide model comparisons should be run independently and combined via stepwise regression with backward selection. This can be useful to reduce the amount of lags included in the confirmatory model. 
#' @param numberofvars This is the number of variables in the model
#' @param ResidualAnalysis Only applies when software = "OpenMx". Analyze the residuals of the time series with OpenMx after factoring out the non-linear effect of time (takes time trends into account). Can be run only at the group level (faster), or it can also be run with a random effect splines of time (slower) by setting ResidualAnalysis = "Individual". Default = "Group" (OPTIONAL)
#' @param OpenMxStartingValues Only applies when software = "OpenMx". Specify the starting values for OpenMx. Since OpenMx will 10 different runs before giving up on convergence this does not usually need to be specified. It should mostly only be specified if there is a convergence issue with OpenMx. Default is 0.3.  (OPTIONAL, UNCOMMONLY SPECIFIED)
#' @param varnames What are the variable names?
#' @param outcome what are the outcome variables?
#' @param numberofpeople How many people are there?
#' @return The output of this function is: The output from the second stage of DTVEM using the state-space approach
#' @export
#' 
#' 

#Adding OpenMx to the Script
OpenMxstage2=function(Timelagsdummy=Timelagsdummy,predictionstart=predictionstart,predictionsend=predictionsend,predictionsinterval=predictionsinterval,variablenamesonlysigall=variablenamesonlysigall,independentpredictors=independentpredictors,k3=k3,numberofvars=numberofvars,OpenMxStartingValues=OpenMxStartingValues,ResidualAnalysis=ResidualAnalysis,varnames=varnames,outcome=outcome,numberofpeople=numberofpeople){
  #numberofvars = Number of variables
  lengthoflags=length((predictionstart/predictionsinterval):((predictionsend)/predictionsinterval)*predictionsinterval)
  #Create Matrices for OpenMx
  OpenMxmatlength=numberofvars*lengthoflags
  
  #COPY IN MGCV CODE AND EDIT
  if(independentpredictors==TRUE){
    independentpredictortvalue=matrix(NA,nrow=length(variablenamesonlysigall),ncol=1) 
    independentpredictorsig=matrix(NA,nrow=length(variablenamesonlysigall),ncol=1) 
    #I TAKE THE NORMAL GAM CODE AND RUN MULTIPLE PRELIMINARY INVESTIGATIONS TO SEE IF EACH VARIABLE IS SIGNIFICANT INDEPENDENTLY BEFORE COMBINING THEM
    for(jjj in 1:length(variablenamesonlysigall)){
      StateSpaceFunctionout=StateSpaceFunction(variablenamestotest=variablenamesonlysigall[jjj],OpenMxmatlength=OpenMxmatlength,lengthoflags=lengthoflags,Timelagsdummy=Timelagsdummy,predictionstart=predictionstart,predictionsend=predictionsend,predictionsinterval=predictionsinterval,variablenamesonlysigall=variablenamesonlysigall,independentpredictors=independentpredictors,k3=k3,numberofvars=numberofvars,OpenMxStartingValues=OpenMxStartingValues,ResidualAnalysis=ResidualAnalysis,varnames=varnames,outcome=outcome,numberofpeople=numberofpeople)
      multisubject=StateSpaceFunctionout$multisubject
      multisubjectRun=StateSpaceFunctionout$multisubjectRun
      OpenMxout=StateSpaceFunctionout$OpenMxout
      if(OpenMxout$pvalue<.05&!is.na(OpenMxout$pvalue)){ #THIS STEP RE-COMPILES THE VARIABLENAMESONLYSIGALL TO ONLY INCLUDE VARIABLES THAT ARE SIGNIFICANT
        independentpredictorsig[jjj]=variablenamesonlysigall[(jjj)]
        independentpredictortvalue[jjj]=OpenMxout$tstat
      }
    }
    variablenamesonlysigall<-c(independentpredictorsig[!is.na(independentpredictorsig)]) #REMOVE NA
    independentpredictortvalue=c(independentpredictortvalue[!is.na(independentpredictorsig)]) #REMOVE NA
    variablenamesonlysigall<-variablenamesonlysigall[rev(order(abs(independentpredictortvalue)))] #Sort by Tvalue
    independentpredictortvalue=independentpredictortvalue[rev(order(abs(independentpredictortvalue)))] #Sort by Tvalue
    primarysig=variablenamesonlysigall[1]
    #print(paste("The value of primarysig is",primarysig))
    for(jjj in 2:length(variablenamesonlysigall)){
      #print(paste("The value of jjj is",jjj))
      independentpredictorsig=matrix(NA,nrow=length(variablenamesonlysigall),ncol=1)
      independentpredictortvalue=matrix(NA,nrow=length(variablenamesonlysigall),ncol=1) 
      for(jjjj in 1:length(variablenamesonlysigall)){
        #print(paste("The value of jjjj is",jjjj))
        widemodel<-as.formula(paste("outcome ~",paste(unique(c(primarysig,variablenamesonlysigall[jjjj])),collapse = " + "),"+ s(time,k=3)",sep=""))
        StateSpaceFunctionout=StateSpaceFunction(variablenamestotest=unique(c(primarysig,variablenamesonlysigall[jjjj])),OpenMxmatlength=OpenMxmatlength,lengthoflags=lengthoflags,Timelagsdummy=Timelagsdummy,predictionstart=predictionstart,predictionsend=predictionsend,predictionsinterval=predictionsinterval,variablenamesonlysigall=variablenamesonlysigall,independentpredictors=independentpredictors,k3=k3,numberofvars=numberofvars,OpenMxStartingValues=OpenMxStartingValues,ResidualAnalysis=ResidualAnalysis,varnames=varnames,outcome=outcome,numberofpeople=numberofpeople)
        multisubject=StateSpaceFunctionout$multisubject
        multisubjectRun=StateSpaceFunctionout$multisubjectRun
        OpenMxout=StateSpaceFunctionout$OpenMxout
        
        if(OpenMxout$pvalue[jjj]<.05&!is.na(OpenMxout$pvalue[jjj])){ #THIS STEP RE-COMPILES THE VARIABLENAMESONLYSIGALL TO ONLY INCLUDE VARIABLES THAT ARE SIGNIFICANT
          independentpredictorsig[jjjj]=variablenamesonlysigall[(jjjj)]
          independentpredictortvalue[jjjj]=OpenMxout$tstat[jjj]
        }
      }
      
      variablenamesonlysigall<-c(independentpredictorsig[!is.na(independentpredictorsig)]) #REMOVE NA
      independentpredictortvalue=c(independentpredictortvalue[!is.na(independentpredictorsig)]) #REMOVE NA
      #print(paste("The value of variablenamesonlysigall is",variablenamesonlysigall))
      #print(paste("The value of independentpredictortvalue is",independentpredictortvalue))
      variablenamesonlysigall<-variablenamesonlysigall[rev(order(abs(independentpredictortvalue)))] #Sort by Tvalue
      independentpredictortvalue=independentpredictortvalue[rev(order(abs(independentpredictortvalue)))] #Sort by Tvalue
      #print(paste("The value of variablenamesonlysigall is",variablenamesonlysigall))
      #print(paste("The value of independentpredictortvalue is",independentpredictortvalue))
      if(length(variablenamesonlysigall)>0){
        primarysig=unique(c(primarysig,variablenamesonlysigall[1]))
        #print(paste("The value of primarysig is",primarysig))
      }else{
        break
      }
    }
    variablenamesonlysigall<-primarysig
  }
  
  
  StateSpaceFunctionout=StateSpaceFunction(variablenamestotest=variablenamesonlysigall,OpenMxmatlength=OpenMxmatlength,lengthoflags=lengthoflags,Timelagsdummy=Timelagsdummy,predictionstart=predictionstart,predictionsend=predictionsend,predictionsinterval=predictionsinterval,variablenamesonlysigall=variablenamesonlysigall,independentpredictors=independentpredictors,k3=k3,numberofvars=numberofvars,OpenMxStartingValues=OpenMxStartingValues,ResidualAnalysis=ResidualAnalysis,varnames=varnames,outcome=outcome,numberofpeople=numberofpeople)
  multisubject=StateSpaceFunctionout$multisubject
  multisubjectRun=StateSpaceFunctionout$multisubjectRun
  OpenMxout=StateSpaceFunctionout$OpenMxout
  
  variablenamesonlysigall<-variablenamesonlysigall[order(variablenamesonlysigall)]
  controlswidelong=variablenamesonlysigall[OpenMxout$pvalue<.05]
  print(paste("Variables that should be controlled for are:",controlswidelong))
  
  OpenMx2returnlist=list("multisubject"=multisubject,"multisubjectRun"=multisubjectRun,"OpenMxout"=OpenMxout,"variablenamesonlysigall"=variablenamesonlysigall,"controlswidelong"=controlswidelong)
  return(OpenMx2returnlist)
  #stop("Reached the OpenMx Testing Stop Point")
}